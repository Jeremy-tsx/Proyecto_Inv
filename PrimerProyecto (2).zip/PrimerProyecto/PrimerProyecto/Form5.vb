﻿Imports MySql.Data.MySqlClient
Imports Org.BouncyCastle.Asn1.Ocsp

Public Class Form5
    Dim conexion As New MySqlConnection("server=localhost;user=root;password=;database=almacen;")

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged
        BuscarProducto(TextBox1.Text.Trim())
    End Sub
    Private Sub BuscarProducto(ByVal buscarProducto As String)
        Try
            Dim con As New ConexionBD()
            Dim query As String = "SELECT * FROM productos WHERE nombre LIKE @busqueda"
            Dim cmd As New MySqlCommand(query, con.Conectar())
            cmd.Parameters.AddWithValue("@busqueda", "%" & buscarProducto & "%")

            Dim reader As MySqlDataReader = cmd.ExecuteReader()

            ' Limpia listas antes de llenarlas
            lstId.Items.Clear()
            lstProductos.Items.Clear()

            While reader.Read()
                lstProductos.Items.Add(reader("nombre").ToString())
                lstId.Items.Add(reader("id_producto").ToString())
            End While

            reader.Close()
            con.Desconectar()
        Catch ex As Exception
            MessageBox.Show("Error al buscar el producto: " & ex.Message)
        End Try
    End Sub

    Private Sub Form5_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        CargarProductos()
        CargarInventario()
        CargarProveedores()
    End Sub

    Private Sub CargarProveedores()
        Try
            Dim con As New ConexionBD()
            Dim query As String = "SELECT id, nombre, correo, telefono, contacto FROM proveedores"
            Dim adaptador As New MySqlDataAdapter(query, con.Conectar())
            Dim tabla As New DataTable()
            adaptador.Fill(tabla)

            ComboBox1.DataSource = tabla
            ComboBox1.DisplayMember = "nombre"
            ComboBox1.DisplayMember = "correo"
            ComboBox1.DisplayMember = "contacto"
            ComboBox1.ValueMember = "id"
            ComboBox1.ValueMember = "telefono"

            con.Desconectar()
        Catch ex As Exception
            MessageBox.Show("Error al cargar proveedores: " & ex.Message)
        End Try
    End Sub

    Private Sub CargarProductos()
        Try
            Dim con As New ConexionBD()
            Dim query As String = "SELECT * FROM productos"
            Dim cmd As New MySqlCommand(query, con.Conectar())
            Dim reader As MySqlDataReader = cmd.ExecuteReader()

            ' Limpia las listas antes de llenarlas
            lstId.Items.Clear()
            lstProductos.Items.Clear()

            While reader.Read()
                lstProductos.Items.Add(reader("nombre").ToString())
                lstId.Items.Add(reader("id_producto").ToString())
            End While

            reader.Close()
            con.Desconectar()
        Catch ex As Exception
            MessageBox.Show("Error al cargar los productos: " & ex.Message)
        End Try
    End Sub


    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub lstId_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lstId.SelectedIndexChanged
        If lstId.SelectedIndex >= 0 AndAlso lstId.SelectedIndex <> lstProductos.SelectedIndex Then
            lstProductos.SelectedIndex = lstId.SelectedIndex
        End If
    End Sub

    Private Sub lstProductos_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lstProductos.SelectedIndexChanged
        If lstProductos.SelectedIndex >= 0 AndAlso lstProductos.SelectedIndex <> lstId.SelectedIndex Then
            lstId.SelectedIndex = lstProductos.SelectedIndex
        End If
    End Sub

    Private Sub Cargar_Productos()
        Try
            Dim con As New ConexionBD()
            Dim query As String = "SELECT productos.nombre, productos.id_producto, categoria.id_categoria, categoria.categoria 
                       FROM productos 
                       INNER JOIN categoria ON productos.id_categoria = categoria.id_categoria 
                       WHERE productos.id_producto = @idProducto"

            Dim cmd As New MySqlCommand(query, con.Conectar())
            cmd.Parameters.AddWithValue("@idProducto", lstId.SelectedItem)

            Using reader As MySqlDataReader = cmd.ExecuteReader()
                If reader.Read() Then
                    lblId_.Text = reader("id_producto").ToString()
                    lblProducto_.Text = reader("nombre").ToString()
                    lblCategoria_.Text = reader("categoria").ToString() ' ← visible
                    lblCategoria_.Tag = reader("id_categoria").ToString() ' ← oculto pero útil
                End If
            End Using

            con.Desconectar()
        Catch ex As Exception
            MessageBox.Show("Error al cargar el producto: " & ex.Message)
        End Try
    End Sub

    Private Sub lstId_DoubleClick(sender As Object, e As EventArgs) Handles lstId.DoubleClick
        Cargar_Productos()
    End Sub

    Private Sub lstProductos_DoubleClick(sender As Object, e As EventArgs) Handles lstProductos.DoubleClick
        Cargar_Productos()
    End Sub

    Private Sub btnAgregar_Click(sender As Object, e As EventArgs) Handles btnAgregar.Click
        If TxtCantidad.Text = "" Or txtCompra.Text = "" Or txtFactura.Text = "" Or txtVenta.Text = "" Then
            MessageBox.Show("Todos los campos son obligatorios. Por favor, complete todos los campos.", "Campos incompletos", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub
        End If

        AgregarProducto()
    End Sub

    Private Sub CargarInventario()
        Try
            conexion.Open()
            Dim query As String = "SELECT * FROM inventario"
            Dim adaptador As New MySqlDataAdapter(query, conexion)
            Dim tabla As New DataTable()
            adaptador.Fill(tabla)

            DataGridView1.DataSource = tabla
            conexion.Close()
        Catch ex As Exception
            MessageBox.Show("Error al cargar inventario: " & ex.Message)
        End Try
    End Sub


    Private Sub AgregarProducto()
        ' Validación
        If txtVenta.Text = "" Or txtCompra.Text = "" Or TxtCantidad.Text = "" Or txtFactura.Text = "" Then
            MessageBox.Show("Todos los campos son obligatorios. Por favor, complete todos los datos.", "Campos incompletos", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub
        End If

        Try
            Dim con As New ConexionBD()
            Dim query As String = "INSERT INTO inventario (id_producto, id_categoria, precio_v, precio_c, cantidad, id_proveedor, factura) 
                               VALUES (@producto, @categoria, @venta, @compra, @cantidad, @proveedor, @factura)"
            Dim cmd As New MySqlCommand(query, con.Conectar())

            ' Asignar parámetros
            cmd.Parameters.AddWithValue("@producto", lstId.SelectedItem)          ' ID del producto
            cmd.Parameters.AddWithValue("@categoria", lblCategoria_.Text)        ' Categoría
            cmd.Parameters.AddWithValue("@venta", Convert.ToDecimal(txtVenta.Text))
            cmd.Parameters.AddWithValue("@compra", Convert.ToDecimal(txtCompra.Text))
            cmd.Parameters.AddWithValue("@cantidad", Convert.ToInt32(TxtCantidad.Text))
            cmd.Parameters.AddWithValue("@proveedor", ComboBox1.SelectedValue)   ' Proveedor
            cmd.Parameters.AddWithValue("@factura", txtFactura.Text)

            cmd.ExecuteNonQuery()
            MessageBox.Show("Producto agregado correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information)
            con.Desconectar()

            ' Limpia los campos
            txtVenta.Clear()
            txtCompra.Clear()
            TxtCantidad.Clear()
            txtFactura.Clear()

            ' Refresca la vista
            CargarProductos()

        Catch ex As Exception
            MessageBox.Show("Error al agregar el producto: " & ex.Message)
        End Try
    End Sub


    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
        Try
            conexion.Open()
            Dim query As String = "SELECT * FROM inventario"
            Dim adaptador As New MySqlDataAdapter(query, conexion)
            Dim tabla As New DataTable()
            adaptador.Fill(tabla)

            DataGridView1.DataSource = tabla
            conexion.Close()
        Catch ex As Exception
            MessageBox.Show("Error al cargar inventario: " & ex.Message)
        End Try
    End Sub
End Class