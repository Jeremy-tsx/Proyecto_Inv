﻿Imports MySql.Data.MySqlClient
Imports Org.BouncyCastle.Asn1.Ocsp

Public Class Form5
    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged
        BuscarProducto(TextBox1.Text.Trim())
    End Sub
    Private Sub BuscarProducto(ByVal buscarProducto As String)
        Try
            Dim con As New ConexionBD()
            Dim query As String = "SELECT * FROM productos WHERE nombre LIKE @busqueda"
            Dim cmd As New MySqlCommand(query, con.Conectar())
            cmd.Parameters.AddWithValue("@busqueda", "%" & buscarProducto & "%")

            Dim reader As MySqlDataReader = cmd.ExecuteReader()

            ' Limpia listas antes de llenarlas
            lstId.Items.Clear()
            lstProductos.Items.Clear()

            While reader.Read()
                lstProductos.Items.Add(reader("nombre").ToString())
                lstId.Items.Add(reader("id_producto").ToString())
            End While

            reader.Close()
            con.Desconectar()
        Catch ex As Exception
            MessageBox.Show("Error al buscar el producto: " & ex.Message)
        End Try
    End Sub

    Private Sub Form5_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        CargarProductos()
        Cargar_Productos()
    End Sub


    Private Sub CargarProductos()
        Try
            Dim con As New ConexionBD()
            Dim query As String = "SELECT * FROM productos"
            Dim cmd As New MySqlCommand(query, con.Conectar())
            Dim reader As MySqlDataReader = cmd.ExecuteReader()

            ' Limpia las listas antes de llenarlas
            lstId.Items.Clear()
            lstProductos.Items.Clear()

            While reader.Read()
                lstProductos.Items.Add(reader("nombre").ToString())
                lstId.Items.Add(reader("id_producto").ToString())
            End While

            reader.Close()
            con.Desconectar()
        Catch ex As Exception
            MessageBox.Show("Error al cargar los productos: " & ex.Message)
        End Try
    End Sub


    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub lstId_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lstId.SelectedIndexChanged
        If lstId.SelectedIndex >= 0 AndAlso lstId.SelectedIndex <> lstProductos.SelectedIndex Then
            lstProductos.SelectedIndex = lstId.SelectedIndex
        End If
    End Sub

    Private Sub lstProductos_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lstProductos.SelectedIndexChanged
        If lstProductos.SelectedIndex >= 0 AndAlso lstProductos.SelectedIndex <> lstId.SelectedIndex Then
            lstId.SelectedIndex = lstProductos.SelectedIndex
        End If
    End Sub

    Private Sub Cargar_Productos()
        Try
            Dim con As New ConexionBD()
            Dim query As String = "SELECT productos.nombre, productos.id_producto, categoria.categoria AS categoria 
                               FROM productos 
                               INNER JOIN categoria ON productos.id_categoria = categoria.id_categoria 
                               WHERE productos.id_producto = @idProducto"

            Dim cmd As New MySqlCommand(query, con.Conectar())
            cmd.Parameters.AddWithValue("@idProducto", lstId.SelectedItem)

            Using reader As MySqlDataReader = cmd.ExecuteReader()
                If reader.Read() Then
                    lblId_.Text = reader("id_producto").ToString()
                    lblProducto_.Text = reader("nombre").ToString()
                    lblCategoria_.Text = reader("categoria").ToString()
                End If
            End Using

            con.Desconectar()
        Catch ex As Exception
            MessageBox.Show("Error al cargar el producto: " & ex.Message)
        End Try
    End Sub

    Private Sub lstId_DoubleClick(sender As Object, e As EventArgs) Handles lstId.DoubleClick
        Cargar_Productos()
    End Sub

    Private Sub lstProductos_DoubleClick(sender As Object, e As EventArgs) Handles lstProductos.DoubleClick
        Cargar_Productos()
    End Sub

    Private Sub btnAgregar_Click(sender As Object, e As EventArgs) Handles btnAgregar.Click
        If TxtCantidad.Text = "" Or txtCompra.Text = "" Or txtFactura.Text = "" Or txtVenta.Text = "" Then
            MessageBox.Show("Todos los campos son obligatorios. Por favor, complete todos los campos.", "Campos incompletos", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub
        End If

        AgregarProducto()
    End Sub

    Private Sub AgregarProducto()
        ' Validación
        If txtVenta.Text = "" Or txtCompra.Text = "" Or txtCantidad.Text = "" Or txtFactura.Text = "" Then
            MessageBox.Show("Todos los campos son obligatorios. Por favor, complete todos los datos.", "Campos incompletos", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub
        End If

        Try
            Dim con As New ConexionBD()
            Dim query As String = "INSERT INTO inventario (nombre, precio_v, precio_c, cantidad, factura) 
                               VALUES (@nombre, @venta, @compra, @cantidad, @factura)"
            Dim cmd As New MySqlCommand(query, con.Conectar())

            'cmd.Parameters.AddWithValue("@nombre", txtProducto.Text)
            cmd.Parameters.AddWithValue("@venta", Convert.ToDecimal(txtVenta.Text))
            cmd.Parameters.AddWithValue("@compra", Convert.ToDecimal(txtCompra.Text))
            cmd.Parameters.AddWithValue("@cantidad", Convert.ToInt32(txtCantidad.Text))
            cmd.Parameters.AddWithValue("@factura", txtFactura.Text)

            cmd.ExecuteNonQuery()
            MessageBox.Show("Producto agregado correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information)
            con.Desconectar()

            ' Limpia los campos después de agregar

            txtVenta.Clear()
            txtCompra.Clear()
            txtCantidad.Clear()
            txtFactura.Clear()

            ' Actualiza la lista de productos
            CargarProductos()

        Catch ex As Exception
            MessageBox.Show("Error al agregar el producto")
        End Try
    End Sub


End Class