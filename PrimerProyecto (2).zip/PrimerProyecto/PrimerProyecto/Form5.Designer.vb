﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form5
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        GroupBox1 = New GroupBox()
        lstId = New ListBox()
        ComboBox1 = New ComboBox()
        Label2 = New Label()
        lstProductos = New ListBox()
        Label1 = New Label()
        TextBox1 = New TextBox()
        DataGridView1 = New DataGridView()
        TxtCantidad = New TextBox()
        txtFactura = New TextBox()
        txtCompra = New TextBox()
        txtVenta = New TextBox()
        btnAgregar = New Button()
        Label3 = New Label()
        Label5 = New Label()
        Label6 = New Label()
        Label7 = New Label()
        Label8 = New Label()
        Factura = New Label()
        Label10 = New Label()
        Label12 = New Label()
        Label13 = New Label()
        lblId = New Label()
        lblId_ = New Label()
        lblCategoria_ = New Label()
        lblProducto_ = New Label()
        GroupBox1.SuspendLayout()
        CType(DataGridView1, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' GroupBox1
        ' 
        GroupBox1.Controls.Add(lstId)
        GroupBox1.Controls.Add(ComboBox1)
        GroupBox1.Controls.Add(Label2)
        GroupBox1.Controls.Add(lstProductos)
        GroupBox1.Controls.Add(Label1)
        GroupBox1.Controls.Add(TextBox1)
        GroupBox1.Location = New Point(1032, 22)
        GroupBox1.Name = "GroupBox1"
        GroupBox1.Size = New Size(295, 340)
        GroupBox1.TabIndex = 0
        GroupBox1.TabStop = False
        GroupBox1.Text = "Seleccione Un Producto"
        ' 
        ' lstId
        ' 
        lstId.FormattingEnabled = True
        lstId.ItemHeight = 15
        lstId.Location = New Point(9, 97)
        lstId.Name = "lstId"
        lstId.Size = New Size(128, 139)
        lstId.TabIndex = 5
        ' 
        ' ComboBox1
        ' 
        ComboBox1.Font = New Font("Segoe UI", 15.75F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        ComboBox1.FormattingEnabled = True
        ComboBox1.Location = New Point(9, 288)
        ComboBox1.Name = "ComboBox1"
        ComboBox1.Size = New Size(276, 38)
        ComboBox1.TabIndex = 4
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Segoe UI Semibold", 20.25F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point, CByte(0))
        Label2.Location = New Point(9, 244)
        Label2.Name = "Label2"
        Label2.Size = New Size(276, 37)
        Label2.TabIndex = 3
        Label2.Text = "Escoger un proveedor"
        ' 
        ' lstProductos
        ' 
        lstProductos.FormattingEnabled = True
        lstProductos.ItemHeight = 15
        lstProductos.Location = New Point(161, 97)
        lstProductos.Name = "lstProductos"
        lstProductos.Size = New Size(128, 139)
        lstProductos.TabIndex = 2
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label1.Location = New Point(200, 47)
        Label1.Name = "Label1"
        Label1.Size = New Size(68, 25)
        Label1.TabIndex = 1
        Label1.Text = "Buscar"
        ' 
        ' TextBox1
        ' 
        TextBox1.Font = New Font("Segoe UI", 15.75F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        TextBox1.Location = New Point(6, 46)
        TextBox1.Name = "TextBox1"
        TextBox1.Size = New Size(174, 35)
        TextBox1.TabIndex = 0
        ' 
        ' DataGridView1
        ' 
        DataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridView1.Location = New Point(12, 400)
        DataGridView1.Name = "DataGridView1"
        DataGridView1.Size = New Size(1315, 325)
        DataGridView1.TabIndex = 1
        ' 
        ' TxtCantidad
        ' 
        TxtCantidad.Font = New Font("Segoe UI Semibold", 15.75F, FontStyle.Bold Or FontStyle.Italic)
        TxtCantidad.Location = New Point(12, 305)
        TxtCantidad.Name = "TxtCantidad"
        TxtCantidad.Size = New Size(151, 36)
        TxtCantidad.TabIndex = 2
        ' 
        ' txtFactura
        ' 
        txtFactura.Font = New Font("Segoe UI Semibold", 15.75F, FontStyle.Bold Or FontStyle.Italic)
        txtFactura.Location = New Point(812, 305)
        txtFactura.Name = "txtFactura"
        txtFactura.Size = New Size(151, 36)
        txtFactura.TabIndex = 3
        txtFactura.Text = "1q"
        ' 
        ' txtCompra
        ' 
        txtCompra.Font = New Font("Segoe UI Semibold", 15.75F, FontStyle.Bold Or FontStyle.Italic)
        txtCompra.Location = New Point(568, 305)
        txtCompra.Name = "txtCompra"
        txtCompra.Size = New Size(151, 36)
        txtCompra.TabIndex = 4
        ' 
        ' txtVenta
        ' 
        txtVenta.Font = New Font("Segoe UI Semibold", 15.75F, FontStyle.Bold Or FontStyle.Italic)
        txtVenta.Location = New Point(288, 305)
        txtVenta.Name = "txtVenta"
        txtVenta.Size = New Size(151, 36)
        txtVenta.TabIndex = 5
        ' 
        ' btnAgregar
        ' 
        btnAgregar.Location = New Point(949, 371)
        btnAgregar.Name = "btnAgregar"
        btnAgregar.Size = New Size(75, 23)
        btnAgregar.TabIndex = 6
        btnAgregar.Text = "Agregar"
        btnAgregar.UseVisualStyleBackColor = True
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Segoe UI Semibold", 18F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point, CByte(0))
        Label3.Location = New Point(364, 22)
        Label3.Name = "Label3"
        Label3.Size = New Size(401, 32)
        Label3.TabIndex = 7
        Label3.Text = "Registrar Productos en el Inventario"
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Font = New Font("Segoe UI", 21.75F, FontStyle.Bold Or FontStyle.Italic)
        Label5.Location = New Point(12, 88)
        Label5.Name = "Label5"
        Label5.Size = New Size(173, 40)
        Label5.TabIndex = 9
        Label5.Text = "Id Producto"
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.Font = New Font("Segoe UI Semibold", 15.75F, FontStyle.Bold Or FontStyle.Italic)
        Label6.Location = New Point(12, 273)
        Label6.Name = "Label6"
        Label6.Size = New Size(99, 30)
        Label6.TabIndex = 10
        Label6.Text = "Cantidad"
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.Font = New Font("Segoe UI Semibold", 15.75F, FontStyle.Bold Or FontStyle.Italic)
        Label7.Location = New Point(288, 273)
        Label7.Name = "Label7"
        Label7.Size = New Size(87, 30)
        Label7.TabIndex = 11
        Label7.Text = "P.Venta"
        ' 
        ' Label8
        ' 
        Label8.AutoSize = True
        Label8.Font = New Font("Segoe UI Semibold", 15.75F, FontStyle.Bold Or FontStyle.Italic)
        Label8.Location = New Point(568, 272)
        Label8.Name = "Label8"
        Label8.Size = New Size(113, 30)
        Label8.TabIndex = 12
        Label8.Text = "P. Compra"
        ' 
        ' Factura
        ' 
        Factura.AutoSize = True
        Factura.Font = New Font("Segoe UI Semibold", 15.75F, FontStyle.Bold Or FontStyle.Italic)
        Factura.Location = New Point(812, 273)
        Factura.Name = "Factura"
        Factura.Size = New Size(90, 30)
        Factura.TabIndex = 13
        Factura.Text = "Factura "
        ' 
        ' Label10
        ' 
        Label10.AutoSize = True
        Label10.Font = New Font("Segoe UI", 21.75F, FontStyle.Bold Or FontStyle.Italic)
        Label10.Location = New Point(568, 88)
        Label10.Name = "Label10"
        Label10.Size = New Size(150, 40)
        Label10.TabIndex = 14
        Label10.Text = "Categoría"
        ' 
        ' Label12
        ' 
        Label12.AutoSize = True
        Label12.Font = New Font("Segoe UI", 21.75F, FontStyle.Bold Or FontStyle.Italic)
        Label12.Location = New Point(282, 88)
        Label12.Name = "Label12"
        Label12.Size = New Size(257, 40)
        Label12.TabIndex = 16
        Label12.Text = "Nombre Producto"
        ' 
        ' Label13
        ' 
        Label13.AutoSize = True
        Label13.Font = New Font("Segoe UI Semibold", 15.75F, FontStyle.Bold Or FontStyle.Italic)
        Label13.Location = New Point(12, 367)
        Label13.Name = "Label13"
        Label13.Size = New Size(238, 30)
        Label13.TabIndex = 17
        Label13.Text = "Inventario de productos"
        ' 
        ' lblId
        ' 
        lblId.AutoSize = True
        lblId.Font = New Font("Segoe UI", 21.75F, FontStyle.Bold Or FontStyle.Italic)
        lblId.Location = New Point(12, 131)
        lblId.Name = "lblId"
        lblId.Size = New Size(0, 40)
        lblId.TabIndex = 18
        ' 
        ' lblId_
        ' 
        lblId_.AutoSize = True
        lblId_.Font = New Font("Segoe UI", 21.75F, FontStyle.Bold Or FontStyle.Italic)
        lblId_.Location = New Point(12, 152)
        lblId_.Name = "lblId_"
        lblId_.Size = New Size(173, 40)
        lblId_.TabIndex = 19
        lblId_.Text = "Id Producto"
        ' 
        ' lblCategoria_
        ' 
        lblCategoria_.AutoSize = True
        lblCategoria_.Font = New Font("Segoe UI", 21.75F, FontStyle.Bold Or FontStyle.Italic)
        lblCategoria_.Location = New Point(568, 152)
        lblCategoria_.Name = "lblCategoria_"
        lblCategoria_.Size = New Size(173, 40)
        lblCategoria_.TabIndex = 20
        lblCategoria_.Text = "Id Producto"
        ' 
        ' lblProducto_
        ' 
        lblProducto_.AutoSize = True
        lblProducto_.Font = New Font("Segoe UI", 21.75F, FontStyle.Bold Or FontStyle.Italic)
        lblProducto_.Location = New Point(288, 152)
        lblProducto_.Name = "lblProducto_"
        lblProducto_.Size = New Size(173, 40)
        lblProducto_.TabIndex = 21
        lblProducto_.Text = "Id Producto"
        ' 
        ' Form5
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(1339, 737)
        Controls.Add(lblProducto_)
        Controls.Add(lblCategoria_)
        Controls.Add(lblId_)
        Controls.Add(lblId)
        Controls.Add(Label13)
        Controls.Add(Label12)
        Controls.Add(Label10)
        Controls.Add(Factura)
        Controls.Add(Label8)
        Controls.Add(Label7)
        Controls.Add(Label6)
        Controls.Add(Label5)
        Controls.Add(Label3)
        Controls.Add(btnAgregar)
        Controls.Add(txtVenta)
        Controls.Add(txtCompra)
        Controls.Add(txtFactura)
        Controls.Add(TxtCantidad)
        Controls.Add(DataGridView1)
        Controls.Add(GroupBox1)
        Name = "Form5"
        Text = "Form5"
        GroupBox1.ResumeLayout(False)
        GroupBox1.PerformLayout()
        CType(DataGridView1, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Label1 As Label
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents lstProductos As ListBox
    Friend WithEvents ComboBox1 As ComboBox
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents TxtCantidad As TextBox
    Friend WithEvents txtFactura As TextBox
    Friend WithEvents txtCompra As TextBox
    Friend WithEvents txtVenta As TextBox
    Friend WithEvents btnAgregar As Button
    Friend WithEvents Label3 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Factura As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents lstId As ListBox
    Friend WithEvents lblId As Label
    Friend WithEvents lblId_ As Label
    Friend WithEvents lblCategoria_ As Label
    Friend WithEvents lblProducto_ As Label
End Class
