﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Proveedores
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        BtnEliminar = New Button()
        btnAgregar = New Button()
        btnActualizar = New Button()
        lstPesoProducto = New ListBox()
        Label5 = New Label()
        lstPresentacionProducto = New ListBox()
        lstCategoríaProducto = New ListBox()
        lstNombreProducto = New ListBox()
        lstIdProducto = New ListBox()
        Label3 = New Label()
        Label2 = New Label()
        Label1 = New Label()
        txtPresentacion = New TextBox()
        txtPeso = New TextBox()
        txtNombre = New TextBox()
        TextBox1 = New TextBox()
        SuspendLayout()
        ' 
        ' BtnEliminar
        ' 
        BtnEliminar.Font = New Font("Segoe UI", 18F)
        BtnEliminar.Location = New Point(1086, 695)
        BtnEliminar.Name = "BtnEliminar"
        BtnEliminar.Size = New Size(115, 45)
        BtnEliminar.TabIndex = 33
        BtnEliminar.Text = "Eliminar"
        BtnEliminar.UseVisualStyleBackColor = True
        ' 
        ' btnAgregar
        ' 
        btnAgregar.Font = New Font("Segoe UI", 18F)
        btnAgregar.Location = New Point(942, 695)
        btnAgregar.Name = "btnAgregar"
        btnAgregar.Size = New Size(117, 45)
        btnAgregar.TabIndex = 32
        btnAgregar.Text = "Agregar"
        btnAgregar.UseVisualStyleBackColor = True
        ' 
        ' btnActualizar
        ' 
        btnActualizar.Font = New Font("Segoe UI", 18F)
        btnActualizar.Location = New Point(791, 695)
        btnActualizar.Name = "btnActualizar"
        btnActualizar.Size = New Size(125, 45)
        btnActualizar.TabIndex = 31
        btnActualizar.Text = "Actualizar"
        btnActualizar.UseVisualStyleBackColor = True
        ' 
        ' lstPesoProducto
        ' 
        lstPesoProducto.FormattingEnabled = True
        lstPesoProducto.ItemHeight = 15
        lstPesoProducto.Location = New Point(965, 355)
        lstPesoProducto.Name = "lstPesoProducto"
        lstPesoProducto.Size = New Size(224, 289)
        lstPesoProducto.TabIndex = 29
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Font = New Font("Segoe UI Semibold", 18F, FontStyle.Bold Or FontStyle.Italic)
        Label5.Location = New Point(358, 111)
        Label5.Name = "Label5"
        Label5.Size = New Size(85, 32)
        Label5.TabIndex = 28
        Label5.Text = "Correo"
        ' 
        ' lstPresentacionProducto
        ' 
        lstPresentacionProducto.FormattingEnabled = True
        lstPresentacionProducto.ItemHeight = 15
        lstPresentacionProducto.Location = New Point(721, 355)
        lstPresentacionProducto.Name = "lstPresentacionProducto"
        lstPresentacionProducto.Size = New Size(228, 289)
        lstPresentacionProducto.TabIndex = 27
        ' 
        ' lstCategoríaProducto
        ' 
        lstCategoríaProducto.FormattingEnabled = True
        lstCategoríaProducto.ItemHeight = 15
        lstCategoríaProducto.Location = New Point(457, 355)
        lstCategoríaProducto.Name = "lstCategoríaProducto"
        lstCategoríaProducto.Size = New Size(258, 289)
        lstCategoríaProducto.TabIndex = 26
        ' 
        ' lstNombreProducto
        ' 
        lstNombreProducto.FormattingEnabled = True
        lstNombreProducto.ItemHeight = 15
        lstNombreProducto.Location = New Point(212, 355)
        lstNombreProducto.Name = "lstNombreProducto"
        lstNombreProducto.Size = New Size(239, 289)
        lstNombreProducto.TabIndex = 25
        ' 
        ' lstIdProducto
        ' 
        lstIdProducto.FormattingEnabled = True
        lstIdProducto.ItemHeight = 15
        lstIdProducto.Location = New Point(70, 355)
        lstIdProducto.Name = "lstIdProducto"
        lstIdProducto.Size = New Size(136, 289)
        lstIdProducto.TabIndex = 24
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Segoe UI Semibold", 18F, FontStyle.Bold Or FontStyle.Italic)
        Label3.Location = New Point(965, 119)
        Label3.Name = "Label3"
        Label3.Size = New Size(110, 32)
        Label3.TabIndex = 23
        Label3.Text = "Contacto"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Segoe UI Semibold", 18F, FontStyle.Bold Or FontStyle.Italic)
        Label2.Location = New Point(730, 114)
        Label2.Name = "Label2"
        Label2.Size = New Size(106, 32)
        Label2.TabIndex = 22
        Label2.Text = "Telefono"
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Segoe UI Semibold", 18F, FontStyle.Bold Or FontStyle.Italic)
        Label1.Location = New Point(99, 111)
        Label1.Name = "Label1"
        Label1.Size = New Size(242, 32)
        Label1.TabIndex = 21
        Label1.Text = "Nombre De Producto"
        ' 
        ' txtPresentacion
        ' 
        txtPresentacion.BackColor = SystemColors.HotTrack
        txtPresentacion.Font = New Font("Segoe UI", 26.25F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        txtPresentacion.Location = New Point(730, 156)
        txtPresentacion.Name = "txtPresentacion"
        txtPresentacion.Size = New Size(209, 54)
        txtPresentacion.TabIndex = 20
        ' 
        ' txtPeso
        ' 
        txtPeso.BackColor = SystemColors.HotTrack
        txtPeso.Font = New Font("Segoe UI", 26.25F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        txtPeso.Location = New Point(965, 157)
        txtPeso.Name = "txtPeso"
        txtPeso.Size = New Size(209, 54)
        txtPeso.TabIndex = 19
        ' 
        ' txtNombre
        ' 
        txtNombre.BackColor = SystemColors.HotTrack
        txtNombre.Font = New Font("Segoe UI", 26.25F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        txtNombre.Location = New Point(99, 157)
        txtNombre.Name = "txtNombre"
        txtNombre.Size = New Size(242, 54)
        txtNombre.TabIndex = 18
        ' 
        ' TextBox1
        ' 
        TextBox1.BackColor = SystemColors.HotTrack
        TextBox1.Font = New Font("Noto Sans", 24F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point, CByte(0))
        TextBox1.Location = New Point(358, 157)
        TextBox1.Name = "TextBox1"
        TextBox1.Size = New Size(341, 51)
        TextBox1.TabIndex = 35
        ' 
        ' Proveedores
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(1253, 754)
        Controls.Add(TextBox1)
        Controls.Add(BtnEliminar)
        Controls.Add(btnAgregar)
        Controls.Add(btnActualizar)
        Controls.Add(lstPesoProducto)
        Controls.Add(Label5)
        Controls.Add(lstPresentacionProducto)
        Controls.Add(lstCategoríaProducto)
        Controls.Add(lstNombreProducto)
        Controls.Add(lstIdProducto)
        Controls.Add(Label3)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Controls.Add(txtPresentacion)
        Controls.Add(txtPeso)
        Controls.Add(txtNombre)
        Name = "Proveedores"
        Text = "Proveedores"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents BtnEliminar As Button
    Friend WithEvents btnAgregar As Button
    Friend WithEvents btnActualizar As Button
    Friend WithEvents lstPesoProducto As ListBox
    Friend WithEvents Label5 As Label
    Friend WithEvents lstPresentacionProducto As ListBox
    Friend WithEvents lstCategoríaProducto As ListBox
    Friend WithEvents lstNombreProducto As ListBox
    Friend WithEvents lstIdProducto As ListBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents txtPresentacion As TextBox
    Friend WithEvents txtPeso As TextBox
    Friend WithEvents txtNombre As TextBox
    Friend WithEvents TextBox1 As TextBox
End Class
