﻿Imports MySql.Data.MySqlClient

Public Class FormPrincipal
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        AgregarEmpleado()
        CargarEmpleados()

    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click, Label2.Click, Label3.Click, Label4.Click, Label5.Click, Label6.Click, Label7.Click, Label8.Click, Label9.Click, Label10.Click, Label11.Click, Label12.Click

    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub AgregarEmpleado()
        Try
            Dim con As New ConexionBD()
            Dim query As String = "INSERT INTO empleado (cedula, nombre, primer_A,
    segundo_A, correo, telefono) VALUES (@cedula, @nombre, @pa, @sa, @correo,
    @telefono)"
            Dim cmd As New MySqlCommand(query, con.Conectar())
            cmd.Parameters.AddWithValue("@cedula", TxtCedula.Text)
            cmd.Parameters.AddWithValue("@nombre", TxtNombre.Text)
            cmd.Parameters.AddWithValue("@pa", TxtPApellido.Text)
            cmd.Parameters.AddWithValue("@sa", TxtSApellido.Text)
            cmd.Parameters.AddWithValue("@correo", TxtCorreo.Text)
            cmd.Parameters.AddWithValue("@telefono", TxtTelefono.Text)
            cmd.ExecuteNonQuery()
            MessageBox.Show("Ingresando Correctamente al registro de empleados .")
            con.Desconectar()

        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)


        End Try
    End Sub

    Private Sub CargarEmpleados()
        Try
            Dim con As New ConexionBD()
            Dim query As String = "SELECT * FROM empleado"
            Dim cmd As New MySqlCommand(query, con.Conectar())
            Dim reader As MySqlDataReader = cmd.ExecuteReader()
            ' Limpia listas antes de llenarlas
            ListCed.Items.Clear()
            ListNombre.Items.Clear()
            ListPApellido.Items.Clear()
            ListSApellido.Items.Clear()
            ListCorreo.Items.Clear()
            ListTelefono.Items.Clear()
            While reader.Read()
                ListCed.Items.Add(reader("cedula").ToString())
                ListNombre.Items.Add(reader("nombre").ToString())
                ListPApellido.Items.Add(reader("primer_A").ToString())
                ListSApellido.Items.Add(reader("segundo_A").ToString())
                ListCorreo.Items.Add(reader("correo").ToString())
                ListTelefono.Items.Add(reader("telefono").ToString())
            End While
            reader.Close()
            con.Desconectar()
        Catch ex As Exception
            MessageBox.Show("Error al cargar empleados: " & ex.Message)
        End Try
    End Sub

    Private Sub ActualizarEmpleado()
        Try
            Dim con As New ConexionBD()
            Dim query As String = "UPDATE empleado SET nombre=@nombre,
primer_A=@pa, segundo_A=@sa, correo=@correo, telefono=@telefono WHERE
cedula=@cedula"
            Dim cmd As New MySqlCommand(query, con.Conectar())
            cmd.Parameters.AddWithValue("@cedula", TxtCedula.Text)
            cmd.Parameters.AddWithValue("@nombre", TxtNombre.Text)
            cmd.Parameters.AddWithValue("@pa", TxtPApellido.Text)
            cmd.Parameters.AddWithValue("@sa", TxtSApellido.Text)
            cmd.Parameters.AddWithValue("@correo", TxtCorreo.Text)
            cmd.Parameters.AddWithValue("@telefono", TxtTelefono.Text)
            cmd.ExecuteNonQuery()
            MessageBox.Show("Empleado actualizado correctamente.")
            con.Desconectar()
            CargarEmpleados()
        Catch ex As Exception
            MessageBox.Show("Error al actualizar: " & ex.Message)
        End Try
    End Sub

    Private Sub EliminarEmpleado()
        Try
            Dim con As New ConexionBD()
            Dim query As String = "DELETE FROM empleado WHERE cedula=@cedula"
            Dim cmd As New MySqlCommand(query, con.Conectar())
            cmd.Parameters.AddWithValue("@cedula", TxtCedula.Text)
            cmd.ExecuteNonQuery()
            MessageBox.Show("Empleado eliminado correctamente.")
            con.Desconectar()
            CargarEmpleados()
        Catch ex As Exception
            MessageBox.Show("Error al eliminar: " & ex.Message)
        End Try
    End Sub






    Private Sub ListBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListCed.SelectedIndexChanged
        If ListCed.SelectedIndex >= 0 Then


            ListNombre.SelectedIndex = ListCed.SelectedIndex
            ListPApellido.SelectedIndex = ListCed.SelectedIndex
            ListSApellido.SelectedIndex = ListCed.SelectedIndex
            ListCorreo.SelectedIndex = ListCed.SelectedIndex
            ListTelefono.SelectedIndex = ListCed.SelectedIndex

            TxtCedula.Text = ListCed.SelectedItem.ToString()
            TxtNombre.Text = ListNombre.SelectedItem.ToString()
            TxtPApellido.Text = ListPApellido.SelectedItem.ToString()
            TxtSApellido.Text = ListSApellido.SelectedItem.ToString()
            TxtCorreo.Text = ListCorreo.SelectedItem.ToString()
            TxtTelefono.Text = ListTelefono.SelectedItem.ToString()

            Button5.Enabled = True
            btnAgregar.Enabled = False
            Button6.Enabled = True
        End If
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles btnAgregar.Click
        ' Verificar campos vacíos
        If TxtCedula.Text = "" Or TxtNombre.Text = "" Or TxtPApellido.Text = "" Or TxtSApellido.Text = "" Or TxtCorreo.Text = "" Or TxtTelefono.Text = "" Then
            MessageBox.Show("Todos los campos son obligatorios. Por favor, complete todos los campos.", "Campos incompletos", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub ' Salir si faltan datos
        End If

        ' Insertar en la base de datos
        Try
            AgregarEmpleado() ' Si hay error aquí, se detendrá
            ' Limpiar campos
            TxtCedula.Clear()
            TxtNombre.Clear()
            TxtPApellido.Clear()
            TxtSApellido.Clear()
            TxtCorreo.Clear()
            TxtTelefono.Clear()

            MessageBox.Show("Empleado registrado correctamente.", "Registro exitoso", MessageBoxButtons.OK, MessageBoxIcon.Information)

        Catch ex As Exception
            MessageBox.Show("Error al agregar el empleado: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub


    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        Me.Close()

    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click

        ActualizarEmpleado()
        btnAgregar.Enabled = True
        Button6.Enabled = False
        Button5.Enabled = False
        ActualizarEmpleado()


    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        ' Verificar si hay un elemento seleccionado en ListCed
        If MsgBox("Está seguro que desea eliminar", vbQuestion + vbYesNo, "Confirmar") = vbYes Then
            EliminarEmpleado()

        Else
                ' Obtener el índice del elemento seleccionado
                Dim index = ListCed.SelectedIndex

                ' Eliminar el elemento en cada ListBox usando el mismo índice
                ListCed.Items.RemoveAt(index)
                ListNombre.Items.RemoveAt(index)
                ListPApellido.Items.RemoveAt(index)
                ListSApellido.Items.RemoveAt(index)
                ListCorreo.Items.RemoveAt(index)
                ListTelefono.Items.RemoveAt(index)
            End If





    End Sub



    Private Sub TxtCedula_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TxtCedula.KeyPress
        If e.KeyChar = Chr(13) Then
            If TxtCedula.Text = "" Then
                MsgBox("No debe dejar ningún campo en blanco", vbExclamation)
            Else
                TxtNombre.Focus()
            End If
        End If
    End Sub

    Private Sub TxtNombre_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TxtNombre.KeyPress
        If e.KeyChar = Chr(13) Then
            If TxtNombre.Text = "" Then
                MsgBox("No debe dejar ningún campo en blanco", vbExclamation)
            Else
                TxtPApellido.Focus()
            End If
        End If

    End Sub

    Private Sub TxtPApellido_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TxtPApellido.KeyPress
        If e.KeyChar = Chr(13) Then
            If TxtPApellido.Text = "" Then
                MsgBox("No debe dejar ningún campo en blanco", vbExclamation)
            Else
                TxtSApellido.Focus()
            End If
        End If
    End Sub

    Private Sub TxtSApellido_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TxtSApellido.KeyPress
        If e.KeyChar = Chr(13) Then
            If TxtSApellido.Text = "" Then
                MsgBox("No debe dejar ningún campo en blanco", vbExclamation)
            Else
                TxtCorreo.Focus()
            End If
        End If
    End Sub

    Private Sub TxtCorreo_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TxtCorreo.KeyPress
        If e.KeyChar = Chr(13) Then
            If TxtCorreo.Text = "" Then
                MsgBox("No debe dejar ningún campo en blanco", vbExclamation)
            Else
                TxtTelefono.Focus()
            End If
        End If

    End Sub

    Private Sub TxtTelefono_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TxtTelefono.KeyPress
        If e.KeyChar = Chr(13) Then
            If TxtTelefono.Text = "" Then
                MsgBox("No debe dejar ningún campo en blanco", vbExclamation)
            Else
                btnAgregar.Focus()
            End If
        End If
    End Sub



    Private Sub TxtCedula_TextChanged(sender As Object, e As EventArgs) Handles TxtCedula.TextChanged

    End Sub

    Private Sub ListNombre_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListNombre.SelectedIndexChanged

    End Sub

    Private Sub ProbarConexion()

        Try
            ' Intentar conectar
            Dim conexion As New ConexionBD()

            ' Si se logra conectar, mostrar mensaje
            conexion.Conectar()
            MessageBox.Show("Conexión exitosa a la base de datos.", "Éxito")
            conexion.Desconectar() ' Desconecta la base de datos
        Catch ex As Exception
            ' Si hay un error, mostrar mensaje
            MessageBox.Show("Error al conectar")
        End Try
    End Sub
    Private Sub MostrarDatosBTN_Click(sender As Object, e As EventArgs) Handles mostrarDatosBTN.Click

        'ProbarConexion()
        AgregarEmpleado()
        CargarEmpleados()



    End Sub



End Class
