﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class productos
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        txtNombre = New TextBox()
        txtPeso = New TextBox()
        txtPresentacion = New TextBox()
        Label1 = New Label()
        Label2 = New Label()
        Label3 = New Label()
        lstIdProducto = New ListBox()
        lstNombreProducto = New ListBox()
        lstCategoríaProducto = New ListBox()
        lstPresentacionProducto = New ListBox()
        Label4 = New Label()
        Label5 = New Label()
        lstPesoProducto = New ListBox()
        CategoriaProducto = New ComboBox()
        btnActualizar = New Button()
        btnAgregar = New Button()
        BtnEliminar = New Button()
        SuspendLayout()
        ' 
        ' txtNombre
        ' 
        txtNombre.BackColor = SystemColors.HotTrack
        txtNombre.Font = New Font("Segoe UI", 26.25F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        txtNombre.Location = New Point(181, 119)
        txtNombre.Name = "txtNombre"
        txtNombre.Size = New Size(209, 54)
        txtNombre.TabIndex = 0
        ' 
        ' txtPeso
        ' 
        txtPeso.BackColor = SystemColors.HotTrack
        txtPeso.Font = New Font("Segoe UI", 26.25F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        txtPeso.Location = New Point(1024, 120)
        txtPeso.Name = "txtPeso"
        txtPeso.Size = New Size(209, 54)
        txtPeso.TabIndex = 1
        ' 
        ' txtPresentacion
        ' 
        txtPresentacion.BackColor = SystemColors.HotTrack
        txtPresentacion.Font = New Font("Segoe UI", 26.25F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        txtPresentacion.Location = New Point(789, 119)
        txtPresentacion.Name = "txtPresentacion"
        txtPresentacion.Size = New Size(209, 54)
        txtPresentacion.TabIndex = 2
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Location = New Point(181, 85)
        Label1.Name = "Label1"
        Label1.Size = New Size(120, 15)
        Label1.TabIndex = 3
        Label1.Text = "Nombre De Producto"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Location = New Point(789, 89)
        Label2.Name = "Label2"
        Label2.Size = New Size(75, 15)
        Label2.TabIndex = 4
        Label2.Text = "Presentación"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Location = New Point(1024, 94)
        Label3.Name = "Label3"
        Label3.Size = New Size(32, 15)
        Label3.TabIndex = 5
        Label3.Text = "Peso"
        ' 
        ' lstIdProducto
        ' 
        lstIdProducto.FormattingEnabled = True
        lstIdProducto.ItemHeight = 15
        lstIdProducto.Location = New Point(152, 317)
        lstIdProducto.Name = "lstIdProducto"
        lstIdProducto.Size = New Size(136, 289)
        lstIdProducto.TabIndex = 6
        ' 
        ' lstNombreProducto
        ' 
        lstNombreProducto.FormattingEnabled = True
        lstNombreProducto.ItemHeight = 15
        lstNombreProducto.Location = New Point(294, 317)
        lstNombreProducto.Name = "lstNombreProducto"
        lstNombreProducto.Size = New Size(271, 289)
        lstNombreProducto.TabIndex = 7
        ' 
        ' lstCategoríaProducto
        ' 
        lstCategoríaProducto.FormattingEnabled = True
        lstCategoríaProducto.ItemHeight = 15
        lstCategoríaProducto.Location = New Point(571, 317)
        lstCategoríaProducto.Name = "lstCategoríaProducto"
        lstCategoríaProducto.Size = New Size(109, 289)
        lstCategoríaProducto.TabIndex = 8
        ' 
        ' lstPresentacionProducto
        ' 
        lstPresentacionProducto.FormattingEnabled = True
        lstPresentacionProducto.ItemHeight = 15
        lstPresentacionProducto.Location = New Point(686, 317)
        lstPresentacionProducto.Name = "lstPresentacionProducto"
        lstPresentacionProducto.Size = New Size(280, 289)
        lstPresentacionProducto.TabIndex = 9
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Location = New Point(0, 0)
        Label4.Name = "Label4"
        Label4.Size = New Size(41, 15)
        Label4.TabIndex = 11
        Label4.Text = "Label4"
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Location = New Point(417, 85)
        Label5.Name = "Label5"
        Label5.Size = New Size(58, 15)
        Label5.TabIndex = 12
        Label5.Text = "Categoría"
        ' 
        ' lstPesoProducto
        ' 
        lstPesoProducto.FormattingEnabled = True
        lstPesoProducto.ItemHeight = 15
        lstPesoProducto.Location = New Point(991, 317)
        lstPesoProducto.Name = "lstPesoProducto"
        lstPesoProducto.Size = New Size(280, 289)
        lstPesoProducto.TabIndex = 13
        ' 
        ' CategoriaProducto
        ' 
        CategoriaProducto.Font = New Font("Segoe UI", 26.25F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        CategoriaProducto.FormattingEnabled = True
        CategoriaProducto.Items.AddRange(New Object() {"Selecione La Categoría", "1: Comida", "2: Farmacia", "3: Ferreteria"})
        CategoriaProducto.Location = New Point(416, 119)
        CategoriaProducto.Name = "CategoriaProducto"
        CategoriaProducto.Size = New Size(334, 55)
        CategoriaProducto.TabIndex = 14
        ' 
        ' btnActualizar
        ' 
        btnActualizar.Font = New Font("Segoe UI", 18.0F)
        btnActualizar.Location = New Point(873, 657)
        btnActualizar.Name = "btnActualizar"
        btnActualizar.Size = New Size(125, 45)
        btnActualizar.TabIndex = 15
        btnActualizar.Text = "Actualizar"
        btnActualizar.UseVisualStyleBackColor = True
        ' 
        ' btnAgregar
        ' 
        btnAgregar.Font = New Font("Segoe UI", 18.0F)
        btnAgregar.Location = New Point(1024, 657)
        btnAgregar.Name = "btnAgregar"
        btnAgregar.Size = New Size(117, 45)
        btnAgregar.TabIndex = 16
        btnAgregar.Text = "Agregar"
        btnAgregar.UseVisualStyleBackColor = True
        ' 
        ' BtnEliminar
        ' 
        BtnEliminar.Font = New Font("Segoe UI", 18.0F)
        BtnEliminar.Location = New Point(1168, 657)
        BtnEliminar.Name = "BtnEliminar"
        BtnEliminar.Size = New Size(115, 45)
        BtnEliminar.TabIndex = 17
        BtnEliminar.Text = "Eliminar"
        BtnEliminar.UseVisualStyleBackColor = True
        ' 
        ' productos
        ' 
        AutoScaleDimensions = New SizeF(7.0F, 15.0F)
        AutoScaleMode = AutoScaleMode.Font
        BackgroundImage = My.Resources.Resources.Blue_and_Orange_Clean_Illustration_Computer_Presentation
        BackgroundImageLayout = ImageLayout.Zoom
        ClientSize = New Size(1337, 793)
        Controls.Add(BtnEliminar)
        Controls.Add(btnAgregar)
        Controls.Add(btnActualizar)
        Controls.Add(CategoriaProducto)
        Controls.Add(lstPesoProducto)
        Controls.Add(Label5)
        Controls.Add(Label4)
        Controls.Add(lstPresentacionProducto)
        Controls.Add(lstCategoríaProducto)
        Controls.Add(lstNombreProducto)
        Controls.Add(lstIdProducto)
        Controls.Add(Label3)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Controls.Add(txtPresentacion)
        Controls.Add(txtPeso)
        Controls.Add(txtNombre)
        Name = "productos"
        Text = "productos"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents txtNombre As TextBox
    Friend WithEvents txtPeso As TextBox
    Friend WithEvents txtPresentacion As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents lstIdProducto As ListBox
    Friend WithEvents lstNombreProducto As ListBox
    Friend WithEvents lstCategoríaProducto As ListBox
    Friend WithEvents lstPresentacionProducto As ListBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents lstPesoProducto As ListBox
    Friend WithEvents CategoriaProducto As ComboBox
    Friend WithEvents btnActualizar As Button
    Friend WithEvents btnAgregar As Button
    Friend WithEvents BtnEliminar As Button
End Class
