﻿Imports MySql.Data.MySqlClient

Public Class productos
    Private Sub productos_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        CargarProductos()
    End Sub

    Private Sub AgregarProducto()
        Try
            Dim con As New ConexionBD()
            Dim query As String = "INSERT INTO productos (nombre, id_categoria,
    presentación, peso) VALUES ( @nombre, @id_Cat, @pre, @pe)"
            Dim cmd As New MySqlCommand(query, con.Conectar())
            cmd.Parameters.AddWithValue("@nombre", txtNombre.Text)
            cmd.Parameters.AddWithValue("@id_Cat", CategoriaProducto.Text)
            cmd.Parameters.AddWithValue("@pre", txtPresentacion.Text)
            cmd.Parameters.AddWithValue("@pe", txtPeso.Text)
            cmd.ExecuteNonQuery()
            MessageBox.Show("Ingresando Correctamente al registro de productos .")
            con.Desconectar()

        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)


        End Try
    End Sub

    Private Sub CargarProductos()
        Try
            Dim con As New ConexionBD()
            Dim query As String = "SELECT * FROM productos"
            Dim cmd As New MySqlCommand(query, con.Conectar())
            Dim reader As MySqlDataReader = cmd.ExecuteReader()
            ' Limpia listas antes de llenarlas
            lstIdProducto.Items.Clear()
            lstNombreProducto.Items.Clear()
            lstCategoríaProducto.Items.Clear()
            lstPresentacionProducto.Items.Clear()
            lstPesoProducto.Items.Clear()
            While reader.Read()
                lstIdProducto.Items.Add(reader("id_Producto").ToString())
                lstNombreProducto.Items.Add(reader("nombre").ToString())
                lstCategoríaProducto.Items.Add(reader("id_categoria").ToString())
                lstPresentacionProducto.Items.Add(reader("presentación").ToString())
                lstPesoProducto.Items.Add(reader("peso").ToString())
            End While
            reader.Close()
            con.Desconectar()
        Catch ex As Exception
            MessageBox.Show("Error al cargar los productos: " & ex.Message)
        End Try
    End Sub

    Private Sub EliminarProducto()
        Try
            Dim con As New ConexionBD()
            Dim query As String = "DELETE FROM productos WHERE id_Producto = @id_Producto"
            Dim cmd As New MySqlCommand(query, con.Conectar())
            cmd.Parameters.AddWithValue("@id_Producto", lstIdProducto.SelectedItem)
            cmd.ExecuteNonQuery()
            MessageBox.Show("Producto eliminado correctamente.")
            con.Desconectar()
            CargarProductos()

        Catch ex As Exception
            MessageBox.Show("Error al eliminar: " & ex.Message)
        End Try
    End Sub
    Private Sub Label5_Click(sender As Object, e As EventArgs) Handles Label5.Click

    End Sub

    Private Sub lstPresentacionProducto_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lstPresentacionProducto.SelectedIndexChanged

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles btnAgregar.Click
        ' Verificar campos vacíos
        If txtNombre.Text = "" Or CategoriaProducto.Text = "" Or txtPresentacion.Text = "" Or txtPeso.Text = "" Then
            MessageBox.Show("Todos los campos son obligatorios. Por favor, complete todos los campos.", "Campos incompletos", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub ' Salir si faltan datos
        End If

        ' Insertar en la base de datos
        Try
            AgregarProducto() ' Si hay error aquí, se detendrá
            CargarProductos()


            ' Limpiar campos
            txtNombre.Clear()
            txtPeso.Clear()
            txtPresentacion.Clear()


            MessageBox.Show("Empleado registrado correctamente.", "Registro exitoso", MessageBoxButtons.OK, MessageBoxIcon.Information)

        Catch ex As Exception
            MessageBox.Show("Error al agregar el empleado: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub txtNombre_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtNombre.KeyPress
        If e.KeyChar = Chr(13) Then
            If txtNombre.Text = "" Then
                MsgBox("No debe dejar ningún campo en blanco", vbExclamation)
            Else
                CategoriaProducto.Focus()
            End If
        End If

    End Sub

    Private Sub CategoriaProducto_KeyPress(sender As Object, e As KeyPressEventArgs) Handles CategoriaProducto.KeyPress
        If e.KeyChar = Chr(13) Then
            If CategoriaProducto.Text = "" Then
                MsgBox("No debe dejar ningún campo en blanco", vbExclamation)
            Else
                txtPresentacion.Focus()
            End If
        End If

    End Sub

    Private Sub txtPresentacion_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtPresentacion.KeyPress
        If e.KeyChar = Chr(13) Then
            If txtPresentacion.Text = "" Then
                MsgBox("No debe dejar ningún campo en blanco", vbExclamation)
            Else
                txtPeso.Focus()
            End If
        End If
    End Sub

    Private Sub txtPeso_TextChanged(sender As Object, e As EventArgs) Handles txtPeso.TextChanged

    End Sub

    Private Sub txtPeso_KeyUp(sender As Object, e As KeyEventArgs) Handles txtPeso.KeyUp

    End Sub

    Private Sub txtPeso_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtPeso.KeyPress
        If e.KeyChar = Chr(13) Then
            If txtPeso.Text = "" Then
                MsgBox("No debe dejar ningún campo en blanco", vbExclamation)
            Else
                btnAgregar.Focus()
            End If
        End If

    End Sub

    Private Sub CategoriaProducto_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CategoriaProducto.SelectedIndexChanged

    End Sub

    Private Sub BtnEliminar_Click(sender As Object, e As EventArgs) Handles BtnEliminar.Click
        If MsgBox("Está seguro que desea eliminar", vbQuestion + vbYesNo, "Confirmar") = vbYes Then
            EliminarProducto()

        End If

    End Sub

    Private Sub lstIdProducto_DoubleClick(sender As Object, e As EventArgs) Handles lstIdProducto.DoubleClick

    End Sub

    Private Sub lstIdProducto_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lstIdProducto.SelectedIndexChanged
        lstNombreProducto.SelectedIndex = lstIdProducto.SelectedIndex
        lstCategoríaProducto.SelectedIndex = lstIdProducto.SelectedIndex
        lstPresentacionProducto.SelectedIndex = lstIdProducto.SelectedIndex
        lstPesoProducto.SelectedIndex = lstIdProducto.SelectedIndex

    End Sub
End Class