﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmProductos
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        btnEliminar = New Button()
        btnActualizar = New Button()
        btnAgregar = New Button()
        ListCatgoria = New ListBox()
        ListNombreProducto = New ListBox()
        ListFechaIngreso = New ListBox()
        ListPVenta = New ListBox()
        ListIdProducto = New ListBox()
        ListCed = New ListBox()
        TxtPVenta = New TextBox()
        TxtNombreProducto = New TextBox()
        Txt_IdProducto = New TextBox()
        TxtCedula = New TextBox()
        Label12 = New Label()
        Label5 = New Label()
        Label11 = New Label()
        Label2 = New Label()
        Label10 = New Label()
        Label4 = New Label()
        Label9 = New Label()
        Label8 = New Label()
        Label6 = New Label()
        Label7 = New Label()
        Label3 = New Label()
        Label1 = New Label()
        Label13 = New Label()
        box_categoria = New ComboBox()
        FechaIngreso = New MonthCalendar()
        ListPCompra = New ListBox()
        Label14 = New Label()
        TxtPCompra = New TextBox()
        Label15 = New Label()
        SuspendLayout()
        ' 
        ' btnEliminar
        ' 
        btnEliminar.BackColor = Color.FromArgb(CByte(0), CByte(192), CByte(0))
        btnEliminar.Font = New Font("Segoe UI", 15.75F, FontStyle.Bold)
        btnEliminar.ForeColor = Color.White
        btnEliminar.Location = New Point(1330, 706)
        btnEliminar.Name = "btnEliminar"
        btnEliminar.Size = New Size(144, 48)
        btnEliminar.TabIndex = 33
        btnEliminar.Text = "Eliminar"
        btnEliminar.UseVisualStyleBackColor = False
        ' 
        ' btnActualizar
        ' 
        btnActualizar.BackColor = Color.FromArgb(CByte(0), CByte(192), CByte(0))
        btnActualizar.Font = New Font("Segoe UI", 15.75F, FontStyle.Bold)
        btnActualizar.ForeColor = Color.White
        btnActualizar.Location = New Point(1164, 706)
        btnActualizar.Name = "btnActualizar"
        btnActualizar.Size = New Size(144, 48)
        btnActualizar.TabIndex = 32
        btnActualizar.Text = "Actualizar"
        btnActualizar.UseVisualStyleBackColor = False
        ' 
        ' btnAgregar
        ' 
        btnAgregar.BackColor = Color.FromArgb(CByte(0), CByte(192), CByte(0))
        btnAgregar.Font = New Font("Segoe UI", 15.75F, FontStyle.Bold)
        btnAgregar.ForeColor = Color.White
        btnAgregar.Location = New Point(997, 706)
        btnAgregar.Name = "btnAgregar"
        btnAgregar.Size = New Size(144, 48)
        btnAgregar.TabIndex = 31
        btnAgregar.Text = "Agregar"
        btnAgregar.UseVisualStyleBackColor = False
        ' 
        ' ListCatgoria
        ' 
        ListCatgoria.BackColor = Color.FromArgb(CByte(0), CByte(192), CByte(0))
        ListCatgoria.Font = New Font("Georgia", 15.75F, FontStyle.Bold Or FontStyle.Italic)
        ListCatgoria.ForeColor = Color.White
        ListCatgoria.FormattingEnabled = True
        ListCatgoria.ItemHeight = 25
        ListCatgoria.Location = New Point(1009, 384)
        ListCatgoria.Name = "ListCatgoria"
        ListCatgoria.Size = New Size(175, 54)
        ListCatgoria.TabIndex = 30
        ' 
        ' ListNombreProducto
        ' 
        ListNombreProducto.BackColor = Color.FromArgb(CByte(0), CByte(192), CByte(0))
        ListNombreProducto.Font = New Font("Georgia", 15.75F, FontStyle.Bold Or FontStyle.Italic)
        ListNombreProducto.ForeColor = Color.White
        ListNombreProducto.FormattingEnabled = True
        ListNombreProducto.ItemHeight = 25
        ListNombreProducto.Location = New Point(1284, 237)
        ListNombreProducto.Name = "ListNombreProducto"
        ListNombreProducto.Size = New Size(180, 54)
        ListNombreProducto.TabIndex = 29
        ' 
        ' ListFechaIngreso
        ' 
        ListFechaIngreso.BackColor = Color.FromArgb(CByte(0), CByte(192), CByte(0))
        ListFechaIngreso.Font = New Font("Georgia", 15.75F, FontStyle.Bold Or FontStyle.Italic)
        ListFechaIngreso.ForeColor = Color.White
        ListFechaIngreso.FormattingEnabled = True
        ListFechaIngreso.ItemHeight = 25
        ListFechaIngreso.Location = New Point(1284, 522)
        ListFechaIngreso.Name = "ListFechaIngreso"
        ListFechaIngreso.Size = New Size(206, 54)
        ListFechaIngreso.TabIndex = 28
        ' 
        ' ListPVenta
        ' 
        ListPVenta.BackColor = Color.FromArgb(CByte(0), CByte(192), CByte(0))
        ListPVenta.Font = New Font("Georgia", 15.75F, FontStyle.Bold Or FontStyle.Italic)
        ListPVenta.ForeColor = Color.White
        ListPVenta.FormattingEnabled = True
        ListPVenta.ItemHeight = 25
        ListPVenta.Location = New Point(1284, 384)
        ListPVenta.Name = "ListPVenta"
        ListPVenta.Size = New Size(180, 54)
        ListPVenta.TabIndex = 27
        ' 
        ' ListIdProducto
        ' 
        ListIdProducto.BackColor = Color.FromArgb(CByte(0), CByte(192), CByte(0))
        ListIdProducto.Font = New Font("Georgia", 15.75F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point, CByte(0))
        ListIdProducto.ForeColor = Color.White
        ListIdProducto.FormattingEnabled = True
        ListIdProducto.ItemHeight = 25
        ListIdProducto.Location = New Point(1011, 237)
        ListIdProducto.Name = "ListIdProducto"
        ListIdProducto.Size = New Size(173, 54)
        ListIdProducto.TabIndex = 26
        ' 
        ' ListCed
        ' 
        ListCed.FormattingEnabled = True
        ListCed.ItemHeight = 15
        ListCed.Location = New Point(-158, 437)
        ListCed.Name = "ListCed"
        ListCed.Size = New Size(130, 154)
        ListCed.TabIndex = 25
        ' 
        ' TxtPVenta
        ' 
        TxtPVenta.BackColor = Color.FromArgb(CByte(0), CByte(192), CByte(0))
        TxtPVenta.BorderStyle = BorderStyle.FixedSingle
        TxtPVenta.Font = New Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        TxtPVenta.ForeColor = Color.White
        TxtPVenta.Location = New Point(262, 384)
        TxtPVenta.Name = "TxtPVenta"
        TxtPVenta.Size = New Size(221, 33)
        TxtPVenta.TabIndex = 21
        ' 
        ' TxtNombreProducto
        ' 
        TxtNombreProducto.BackColor = Color.FromArgb(CByte(0), CByte(192), CByte(0))
        TxtNombreProducto.BorderStyle = BorderStyle.FixedSingle
        TxtNombreProducto.Font = New Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        TxtNombreProducto.ForeColor = Color.White
        TxtNombreProducto.Location = New Point(284, 216)
        TxtNombreProducto.Name = "TxtNombreProducto"
        TxtNombreProducto.Size = New Size(221, 33)
        TxtNombreProducto.TabIndex = 24
        ' 
        ' Txt_IdProducto
        ' 
        Txt_IdProducto.BackColor = Color.FromArgb(CByte(0), CByte(192), CByte(0))
        Txt_IdProducto.BorderStyle = BorderStyle.FixedSingle
        Txt_IdProducto.Font = New Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Txt_IdProducto.ForeColor = Color.White
        Txt_IdProducto.Location = New Point(41, 216)
        Txt_IdProducto.Name = "Txt_IdProducto"
        Txt_IdProducto.Size = New Size(169, 33)
        Txt_IdProducto.TabIndex = 20
        ' 
        ' TxtCedula
        ' 
        TxtCedula.BorderStyle = BorderStyle.FixedSingle
        TxtCedula.Font = New Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        TxtCedula.ForeColor = SystemColors.InfoText
        TxtCedula.Location = New Point(-164, 77)
        TxtCedula.Name = "TxtCedula"
        TxtCedula.Size = New Size(122, 33)
        TxtCedula.TabIndex = 19
        ' 
        ' Label12
        ' 
        Label12.AutoSize = True
        Label12.BackColor = Color.Yellow
        Label12.FlatStyle = FlatStyle.Flat
        Label12.Font = New Font("Linux Libertine Display G", 24F, FontStyle.Bold)
        Label12.ForeColor = Color.Red
        Label12.Location = New Point(1009, 337)
        Label12.Name = "Label12"
        Label12.Size = New Size(151, 37)
        Label12.TabIndex = 17
        Label12.Text = "Categoría"
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.BackColor = Color.Yellow
        Label5.FlatStyle = FlatStyle.Flat
        Label5.Font = New Font("Linux Libertine Display G", 24F, FontStyle.Bold)
        Label5.ForeColor = Color.Red
        Label5.Location = New Point(262, 329)
        Label5.Name = "Label5"
        Label5.Size = New Size(192, 37)
        Label5.TabIndex = 16
        Label5.Text = "Precio Venta"
        ' 
        ' Label11
        ' 
        Label11.AutoSize = True
        Label11.BackColor = Color.Yellow
        Label11.BorderStyle = BorderStyle.Fixed3D
        Label11.FlatStyle = FlatStyle.Flat
        Label11.Font = New Font("Linux Libertine Display G", 24F, FontStyle.Bold)
        Label11.ForeColor = Color.Red
        Label11.Location = New Point(1009, 184)
        Label11.Name = "Label11"
        Label11.Size = New Size(185, 39)
        Label11.TabIndex = 15
        Label11.Text = "Id_Producto"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.BackColor = Color.Yellow
        Label2.BorderStyle = BorderStyle.Fixed3D
        Label2.FlatStyle = FlatStyle.Flat
        Label2.Font = New Font("Linux Libertine Display G", 24F, FontStyle.Bold)
        Label2.ForeColor = Color.Red
        Label2.Location = New Point(41, 176)
        Label2.Name = "Label2"
        Label2.Size = New Size(171, 39)
        Label2.TabIndex = 14
        Label2.Text = "Id Protucto"
        ' 
        ' Label10
        ' 
        Label10.AutoSize = True
        Label10.BackColor = Color.Yellow
        Label10.FlatStyle = FlatStyle.Flat
        Label10.Font = New Font("Linux Libertine Display G", 24F, FontStyle.Bold)
        Label10.ForeColor = Color.Red
        Label10.Location = New Point(1282, 337)
        Label10.Name = "Label10"
        Label10.Size = New Size(192, 37)
        Label10.TabIndex = 13
        Label10.Text = "Precio Venta"
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.BackColor = Color.Yellow
        Label4.FlatStyle = FlatStyle.Flat
        Label4.Font = New Font("Linux Libertine Display G", 24F, FontStyle.Bold)
        Label4.ForeColor = Color.Red
        Label4.Location = New Point(273, 456)
        Label4.Name = "Label4"
        Label4.Size = New Size(205, 37)
        Label4.TabIndex = 12
        Label4.Text = "Fecha ingreso"
        ' 
        ' Label9
        ' 
        Label9.AutoSize = True
        Label9.BackColor = Color.Yellow
        Label9.FlatStyle = FlatStyle.Flat
        Label9.Font = New Font("Linux Libertine Display G", 24F, FontStyle.Bold)
        Label9.ForeColor = Color.Red
        Label9.Location = New Point(1284, 482)
        Label9.Name = "Label9"
        Label9.Size = New Size(206, 37)
        Label9.TabIndex = 11
        Label9.Text = "Fecha Ingreso"
        ' 
        ' Label8
        ' 
        Label8.AutoSize = True
        Label8.BackColor = Color.Yellow
        Label8.BorderStyle = BorderStyle.Fixed3D
        Label8.FlatStyle = FlatStyle.Flat
        Label8.Font = New Font("Linux Libertine Display G", 24F, FontStyle.Bold)
        Label8.ForeColor = Color.Red
        Label8.Location = New Point(1302, 184)
        Label8.Name = "Label8"
        Label8.Size = New Size(127, 39)
        Label8.TabIndex = 10
        Label8.Text = "Nombre"
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.BackColor = Color.Yellow
        Label6.FlatStyle = FlatStyle.Flat
        Label6.Font = New Font("Linux Libertine Display G", 24F, FontStyle.Bold)
        Label6.ForeColor = Color.Red
        Label6.Location = New Point(41, 329)
        Label6.Name = "Label6"
        Label6.Size = New Size(151, 37)
        Label6.TabIndex = 9
        Label6.Text = "Categoría"
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.FlatStyle = FlatStyle.Flat
        Label7.Font = New Font("Linux Libertine Display G", 24F, FontStyle.Bold)
        Label7.Location = New Point(-158, 384)
        Label7.Name = "Label7"
        Label7.Size = New Size(113, 37)
        Label7.TabIndex = 8
        Label7.Text = "Cedula"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.BackColor = Color.Yellow
        Label3.BorderStyle = BorderStyle.Fixed3D
        Label3.FlatStyle = FlatStyle.Flat
        Label3.Font = New Font("Linux Libertine Display G", 24F, FontStyle.Bold)
        Label3.ForeColor = Color.Red
        Label3.Location = New Point(340, 176)
        Label3.Name = "Label3"
        Label3.Size = New Size(127, 39)
        Label3.TabIndex = 18
        Label3.Text = "Nombre"
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.FlatStyle = FlatStyle.Flat
        Label1.Font = New Font("Linux Libertine Display G", 24F, FontStyle.Bold)
        Label1.Location = New Point(-164, 37)
        Label1.Name = "Label1"
        Label1.Size = New Size(113, 37)
        Label1.TabIndex = 7
        Label1.Text = "Cedula"
        ' 
        ' Label13
        ' 
        Label13.AutoSize = True
        Label13.BackColor = Color.Transparent
        Label13.Font = New Font("Wide Latin", 21.75F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point, CByte(0))
        Label13.ForeColor = Color.FromArgb(CByte(255), CByte(128), CByte(0))
        Label13.Location = New Point(596, 72)
        Label13.Name = "Label13"
        Label13.Size = New Size(395, 36)
        Label13.TabIndex = 34
        Label13.Text = "INVENTARIO"
        ' 
        ' box_categoria
        ' 
        box_categoria.AccessibleDescription = ""
        box_categoria.AccessibleName = ""
        box_categoria.BackColor = Color.FromArgb(CByte(0), CByte(192), CByte(0))
        box_categoria.Font = New Font("Segoe UI", 15.75F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        box_categoria.ForeColor = Color.White
        box_categoria.FormattingEnabled = True
        box_categoria.Items.AddRange(New Object() {"Farmacia", "Comida", "Ferretería"})
        box_categoria.Location = New Point(41, 384)
        box_categoria.Name = "box_categoria"
        box_categoria.Size = New Size(151, 38)
        box_categoria.TabIndex = 36
        ' 
        ' FechaIngreso
        ' 
        FechaIngreso.BackColor = Color.FromArgb(CByte(0), CByte(192), CByte(0))
        FechaIngreso.ForeColor = Color.Black
        FechaIngreso.Location = New Point(275, 502)
        FechaIngreso.Name = "FechaIngreso"
        FechaIngreso.TabIndex = 62
        FechaIngreso.TitleBackColor = Color.FromArgb(CByte(0), CByte(192), CByte(0))
        FechaIngreso.TitleForeColor = Color.FromArgb(CByte(0), CByte(192), CByte(0))
        ' 
        ' ListPCompra
        ' 
        ListPCompra.BackColor = Color.FromArgb(CByte(0), CByte(192), CByte(0))
        ListPCompra.Font = New Font("Georgia", 15.75F, FontStyle.Bold Or FontStyle.Italic)
        ListPCompra.ForeColor = Color.White
        ListPCompra.FormattingEnabled = True
        ListPCompra.ItemHeight = 25
        ListPCompra.Location = New Point(1009, 521)
        ListPCompra.Name = "ListPCompra"
        ListPCompra.Size = New Size(180, 54)
        ListPCompra.TabIndex = 64
        ' 
        ' Label14
        ' 
        Label14.AutoSize = True
        Label14.BackColor = Color.Yellow
        Label14.FlatStyle = FlatStyle.Flat
        Label14.Font = New Font("Linux Libertine Display G", 24F, FontStyle.Bold)
        Label14.ForeColor = Color.Red
        Label14.Location = New Point(1009, 481)
        Label14.Name = "Label14"
        Label14.Size = New Size(220, 37)
        Label14.TabIndex = 63
        Label14.Text = "Precio Compra"
        ' 
        ' TxtPCompra
        ' 
        TxtPCompra.BackColor = Color.FromArgb(CByte(0), CByte(192), CByte(0))
        TxtPCompra.BorderStyle = BorderStyle.FixedSingle
        TxtPCompra.Font = New Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        TxtPCompra.ForeColor = Color.White
        TxtPCompra.Location = New Point(41, 511)
        TxtPCompra.Name = "TxtPCompra"
        TxtPCompra.Size = New Size(195, 33)
        TxtPCompra.TabIndex = 66
        ' 
        ' Label15
        ' 
        Label15.AutoSize = True
        Label15.BackColor = Color.Yellow
        Label15.FlatStyle = FlatStyle.Flat
        Label15.Font = New Font("Linux Libertine Display G", 24F, FontStyle.Bold)
        Label15.ForeColor = Color.Red
        Label15.Location = New Point(41, 456)
        Label15.Name = "Label15"
        Label15.Size = New Size(220, 37)
        Label15.TabIndex = 65
        Label15.Text = "Precio Compra"
        ' 
        ' FrmProductos
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackgroundImage = My.Resources.Resources.supermercado_pali_en_leon_nicaragua_visit_leon_nicaragua_orig
        BackgroundImageLayout = ImageLayout.Stretch
        ClientSize = New Size(1486, 766)
        Controls.Add(TxtPCompra)
        Controls.Add(Label15)
        Controls.Add(ListPCompra)
        Controls.Add(Label14)
        Controls.Add(FechaIngreso)
        Controls.Add(box_categoria)
        Controls.Add(Label13)
        Controls.Add(btnEliminar)
        Controls.Add(btnActualizar)
        Controls.Add(btnAgregar)
        Controls.Add(ListCatgoria)
        Controls.Add(ListNombreProducto)
        Controls.Add(ListFechaIngreso)
        Controls.Add(ListPVenta)
        Controls.Add(ListIdProducto)
        Controls.Add(ListCed)
        Controls.Add(TxtPVenta)
        Controls.Add(TxtNombreProducto)
        Controls.Add(Txt_IdProducto)
        Controls.Add(TxtCedula)
        Controls.Add(Label12)
        Controls.Add(Label5)
        Controls.Add(Label11)
        Controls.Add(Label2)
        Controls.Add(Label10)
        Controls.Add(Label4)
        Controls.Add(Label9)
        Controls.Add(Label8)
        Controls.Add(Label6)
        Controls.Add(Label7)
        Controls.Add(Label3)
        Controls.Add(Label1)
        FormBorderStyle = FormBorderStyle.FixedToolWindow
        Name = "FrmProductos"
        Text = "Form3"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents btnEliminar As Button
    Friend WithEvents btnActualizar As Button
    Friend WithEvents btnAgregar As Button
    Friend WithEvents ListCatgoria As ListBox
    Friend WithEvents ListNombreProducto As ListBox
    Friend WithEvents ListFechaIngreso As ListBox
    Friend WithEvents ListPVenta As ListBox
    Friend WithEvents ListIdProducto As ListBox
    Friend WithEvents ListCed As ListBox
    Friend WithEvents TxtPVenta As TextBox
    Friend WithEvents TxtNombreProducto As TextBox
    Friend WithEvents Txt_IdProducto As TextBox
    Friend WithEvents TxtCedula As TextBox
    Friend WithEvents Label12 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents box_categoria As ComboBox
    Friend WithEvents FechaIngreso As MonthCalendar
    Friend WithEvents ListPCompra As ListBox
    Friend WithEvents Label14 As Label
    Friend WithEvents TxtPCompra As TextBox
    Friend WithEvents Label15 As Label
End Class
