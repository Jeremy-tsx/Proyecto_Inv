﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form4
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        ComboBox1 = New ComboBox()
        Label13 = New Label()
        Button6 = New Button()
        Button5 = New Button()
        btnAgregar = New Button()
        ListSApellido = New ListBox()
        ListPApellido = New ListBox()
        ListTelefono = New ListBox()
        ListCorreo = New ListBox()
        ListNombre = New ListBox()
        TxtSApellido = New TextBox()
        Txt_NOMBREPRODUCTO = New TextBox()
        TXT_IDPRODUCTO = New TextBox()
        Label12 = New Label()
        Label5 = New Label()
        Label11 = New Label()
        Label2 = New Label()
        Label10 = New Label()
        Label4 = New Label()
        Label9 = New Label()
        Label8 = New Label()
        Label6 = New Label()
        Label3 = New Label()
        MonthCalendar1 = New MonthCalendar()
        SuspendLayout()
        ' 
        ' ComboBox1
        ' 
        ComboBox1.FormattingEnabled = True
        ComboBox1.Items.AddRange(New Object() {"Farmacia", "Comida", "Ferretería"})
        ComboBox1.Location = New Point(525, 128)
        ComboBox1.Name = "ComboBox1"
        ComboBox1.Size = New Size(151, 23)
        ComboBox1.TabIndex = 60
        ' 
        ' Label13
        ' 
        Label13.AutoSize = True
        Label13.BackColor = SystemColors.MenuBar
        Label13.Font = New Font("Palatino Linotype", 21.75F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point, CByte(0))
        Label13.ForeColor = SystemColors.ControlText
        Label13.Location = New Point(574, 26)
        Label13.Name = "Label13"
        Label13.Size = New Size(205, 38)
        Label13.TabIndex = 59
        Label13.Text = "PRODUCTOS"
        ' 
        ' Button6
        ' 
        Button6.Font = New Font("Segoe UI", 15.75F, FontStyle.Bold)
        Button6.Location = New Point(1142, 579)
        Button6.Name = "Button6"
        Button6.Size = New Size(150, 48)
        Button6.TabIndex = 58
        Button6.Text = "Eliminar"
        Button6.UseVisualStyleBackColor = True
        ' 
        ' Button5
        ' 
        Button5.Font = New Font("Segoe UI", 15.75F, FontStyle.Bold)
        Button5.Location = New Point(976, 579)
        Button5.Name = "Button5"
        Button5.Size = New Size(150, 48)
        Button5.TabIndex = 57
        Button5.Text = "Actualizar"
        Button5.UseVisualStyleBackColor = True
        ' 
        ' btnAgregar
        ' 
        btnAgregar.Font = New Font("Segoe UI", 15.75F, FontStyle.Bold)
        btnAgregar.Location = New Point(809, 579)
        btnAgregar.Name = "btnAgregar"
        btnAgregar.Size = New Size(150, 48)
        btnAgregar.TabIndex = 56
        btnAgregar.Text = "Agregar"
        btnAgregar.UseVisualStyleBackColor = True
        ' 
        ' ListSApellido
        ' 
        ListSApellido.FormattingEnabled = True
        ListSApellido.ItemHeight = 15
        ListSApellido.Location = New Point(542, 483)
        ListSApellido.Name = "ListSApellido"
        ListSApellido.Size = New Size(151, 64)
        ListSApellido.TabIndex = 55
        ' 
        ' ListPApellido
        ' 
        ListPApellido.FormattingEnabled = True
        ListPApellido.ItemHeight = 15
        ListPApellido.Location = New Point(242, 483)
        ListPApellido.Name = "ListPApellido"
        ListPApellido.Size = New Size(239, 64)
        ListPApellido.TabIndex = 54
        ' 
        ' ListTelefono
        ' 
        ListTelefono.FormattingEnabled = True
        ListTelefono.ItemHeight = 15
        ListTelefono.Location = New Point(1052, 483)
        ListTelefono.Name = "ListTelefono"
        ListTelefono.Size = New Size(199, 64)
        ListTelefono.TabIndex = 53
        ' 
        ' ListCorreo
        ' 
        ListCorreo.FormattingEnabled = True
        ListCorreo.ItemHeight = 15
        ListCorreo.Location = New Point(788, 483)
        ListCorreo.Name = "ListCorreo"
        ListCorreo.Size = New Size(209, 64)
        ListCorreo.TabIndex = 52
        ' 
        ' ListNombre
        ' 
        ListNombre.FormattingEnabled = True
        ListNombre.ItemHeight = 15
        ListNombre.Location = New Point(32, 483)
        ListNombre.Name = "ListNombre"
        ListNombre.Size = New Size(132, 64)
        ListNombre.TabIndex = 51
        ' 
        ' TxtSApellido
        ' 
        TxtSApellido.BorderStyle = BorderStyle.FixedSingle
        TxtSApellido.Font = New Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        TxtSApellido.ForeColor = SystemColors.InfoText
        TxtSApellido.Location = New Point(37, 213)
        TxtSApellido.Name = "TxtSApellido"
        TxtSApellido.Size = New Size(265, 33)
        TxtSApellido.TabIndex = 48
        ' 
        ' Txt_NOMBREPRODUCTO
        ' 
        Txt_NOMBREPRODUCTO.BorderStyle = BorderStyle.FixedSingle
        Txt_NOMBREPRODUCTO.Font = New Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Txt_NOMBREPRODUCTO.ForeColor = SystemColors.InfoText
        Txt_NOMBREPRODUCTO.Location = New Point(241, 121)
        Txt_NOMBREPRODUCTO.Name = "Txt_NOMBREPRODUCTO"
        Txt_NOMBREPRODUCTO.Size = New Size(245, 33)
        Txt_NOMBREPRODUCTO.TabIndex = 50
        ' 
        ' TXT_IDPRODUCTO
        ' 
        TXT_IDPRODUCTO.BorderStyle = BorderStyle.FixedSingle
        TXT_IDPRODUCTO.Font = New Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        TXT_IDPRODUCTO.ForeColor = SystemColors.InfoText
        TXT_IDPRODUCTO.Location = New Point(37, 121)
        TXT_IDPRODUCTO.Name = "TXT_IDPRODUCTO"
        TXT_IDPRODUCTO.Size = New Size(169, 33)
        TXT_IDPRODUCTO.TabIndex = 47
        ' 
        ' Label12
        ' 
        Label12.AutoSize = True
        Label12.FlatStyle = FlatStyle.Flat
        Label12.Font = New Font("Linux Libertine Display G", 24F, FontStyle.Bold)
        Label12.Location = New Point(542, 436)
        Label12.Name = "Label12"
        Label12.Size = New Size(151, 37)
        Label12.TabIndex = 45
        Label12.Text = "Categoria"
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.FlatStyle = FlatStyle.Flat
        Label5.Font = New Font("Linux Libertine Display G", 24F, FontStyle.Bold)
        Label5.Location = New Point(37, 173)
        Label5.Name = "Label5"
        Label5.Size = New Size(258, 37)
        Label5.TabIndex = 44
        Label5.Text = "Segundo Apellido"
        ' 
        ' Label11
        ' 
        Label11.AutoSize = True
        Label11.FlatStyle = FlatStyle.Flat
        Label11.Font = New Font("Linux Libertine Display G", 24F, FontStyle.Bold)
        Label11.Location = New Point(32, 436)
        Label11.Name = "Label11"
        Label11.Size = New Size(175, 37)
        Label11.TabIndex = 43
        Label11.Text = "Id Producto"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.FlatStyle = FlatStyle.Flat
        Label2.Font = New Font("Linux Libertine Display G", 24F, FontStyle.Bold)
        Label2.Location = New Point(37, 81)
        Label2.Name = "Label2"
        Label2.Size = New Size(169, 37)
        Label2.TabIndex = 42
        Label2.Text = "Id Protucto"
        ' 
        ' Label10
        ' 
        Label10.AutoSize = True
        Label10.FlatStyle = FlatStyle.Flat
        Label10.Font = New Font("Linux Libertine Display G", 24F, FontStyle.Bold)
        Label10.Location = New Point(788, 436)
        Label10.Name = "Label10"
        Label10.Size = New Size(110, 37)
        Label10.TabIndex = 41
        Label10.Text = "Correo"
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.FlatStyle = FlatStyle.Flat
        Label4.Font = New Font("Linux Libertine Display G", 24F, FontStyle.Bold)
        Label4.Location = New Point(332, 173)
        Label4.Name = "Label4"
        Label4.Size = New Size(205, 37)
        Label4.TabIndex = 40
        Label4.Text = "Fecha ingreso"
        ' 
        ' Label9
        ' 
        Label9.AutoSize = True
        Label9.FlatStyle = FlatStyle.Flat
        Label9.Font = New Font("Linux Libertine Display G", 24F, FontStyle.Bold)
        Label9.Location = New Point(1046, 436)
        Label9.Name = "Label9"
        Label9.Size = New Size(205, 37)
        Label9.TabIndex = 39
        Label9.Text = "Fecha ingreso"
        ' 
        ' Label8
        ' 
        Label8.AutoSize = True
        Label8.FlatStyle = FlatStyle.Flat
        Label8.Font = New Font("Linux Libertine Display G", 24F, FontStyle.Bold)
        Label8.Location = New Point(242, 436)
        Label8.Name = "Label8"
        Label8.Size = New Size(125, 37)
        Label8.TabIndex = 38
        Label8.Text = "Nombre"
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.FlatStyle = FlatStyle.Flat
        Label6.Font = New Font("Linux Libertine Display G", 24F, FontStyle.Bold)
        Label6.Location = New Point(525, 81)
        Label6.Name = "Label6"
        Label6.Size = New Size(151, 37)
        Label6.TabIndex = 37
        Label6.Text = "Categoría"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.FlatStyle = FlatStyle.Flat
        Label3.Font = New Font("Linux Libertine Display G", 24F, FontStyle.Bold)
        Label3.Location = New Point(241, 81)
        Label3.Name = "Label3"
        Label3.Size = New Size(125, 37)
        Label3.TabIndex = 46
        Label3.Text = "Nombre"
        ' 
        ' MonthCalendar1
        ' 
        MonthCalendar1.Location = New Point(332, 213)
        MonthCalendar1.Name = "MonthCalendar1"
        MonthCalendar1.TabIndex = 61
        ' 
        ' Form4
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(1324, 644)
        Controls.Add(MonthCalendar1)
        Controls.Add(ComboBox1)
        Controls.Add(Label13)
        Controls.Add(Button6)
        Controls.Add(Button5)
        Controls.Add(btnAgregar)
        Controls.Add(ListSApellido)
        Controls.Add(ListPApellido)
        Controls.Add(ListTelefono)
        Controls.Add(ListCorreo)
        Controls.Add(ListNombre)
        Controls.Add(TxtSApellido)
        Controls.Add(Txt_NOMBREPRODUCTO)
        Controls.Add(TXT_IDPRODUCTO)
        Controls.Add(Label12)
        Controls.Add(Label5)
        Controls.Add(Label11)
        Controls.Add(Label2)
        Controls.Add(Label10)
        Controls.Add(Label4)
        Controls.Add(Label9)
        Controls.Add(Label8)
        Controls.Add(Label6)
        Controls.Add(Label3)
        Name = "Form4"
        Text = "Form4"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents ComboBox1 As ComboBox
    Friend WithEvents Label13 As Label
    Friend WithEvents Button6 As Button
    Friend WithEvents Button5 As Button
    Friend WithEvents btnAgregar As Button
    Friend WithEvents ListSApellido As ListBox
    Friend WithEvents ListPApellido As ListBox
    Friend WithEvents ListTelefono As ListBox
    Friend WithEvents ListCorreo As ListBox
    Friend WithEvents ListNombre As ListBox
    Friend WithEvents TxtSApellido As TextBox
    Friend WithEvents Txt_NOMBREPRODUCTO As TextBox
    Friend WithEvents TXT_IDPRODUCTO As TextBox
    Friend WithEvents Label12 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents MonthCalendar1 As MonthCalendar
End Class
