﻿Imports MySql.Data.MySqlClient
Public Class ConexionBD
Private conexion As MySqlConnection
    Private cadena As String = "server=localhost;userid=root;password=;database=almacen"
    Public Function Conectar() As MySqlConnection
If conexion Is Nothing Then
conexion = New MySqlConnection(cadena)
End If
If conexion.State = ConnectionState.Closed Then
conexion.Open()
End If
Return conexion
 End Function

    Public Sub Desconectar()
        If conexion IsNot Nothing AndAlso conexion.State = ConnectionState.Open Then
            conexion.Close()
        End If
    End Sub
End Class

