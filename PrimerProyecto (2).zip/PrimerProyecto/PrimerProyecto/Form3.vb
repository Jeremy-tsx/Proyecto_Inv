﻿Public Class FrmProductos
    Private Sub FrmProductos_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Label13_Click(sender As Object, e As EventArgs) Handles Label13.Click

    End Sub

    Private Sub CheckedListBox1_SelectedIndexChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles box_categoria.SelectedIndexChanged

    End Sub

    Private Sub Label4_Click(sender As Object, e As EventArgs) Handles Label4.Click

    End Sub

    Private Sub Label12_Click(sender As Object, e As EventArgs) Handles Label12.Click

    End Sub

    Private Sub Label10_Click(sender As Object, e As EventArgs) Handles Label10.Click

    End Sub

    Private Sub btnAgregar_Click(sender As Object, e As EventArgs) Handles btnAgregar.Click
        If Txt_IdProducto.Text = "" Or TxtNombreProducto.Text = "" Or box_categoria.Text = "" Or FechaIngreso.SelectionStart = Nothing Or TxtPVenta.Text = "" Then
            MessageBox.Show("Todos los campos son obligatorios. Por favor, complete todos los campos.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        Else

            ListIdProducto.Items.Add(Txt_IdProducto.Text)
            ListNombreProducto.Items.Add(TxtNombreProducto.Text)
            ListCatgoria.Items.Add(box_categoria.Text)
            ListFechaIngreso.Items.Add(FechaIngreso.SelectionStart.ToShortDateString)
            ListPVenta.Items.Add(TxtPVenta.Text)
            ListPCompra.Items.Add(TxtPCompra.Text)
            Txt_IdProducto.Text = ""
            TxtNombreProducto.Text = ""
            box_categoria.SelectedIndex = -1
            FechaIngreso.SetDate(DateTime.Now)
            TxtPVenta.Text = ""
            TxtPCompra.Text = ""
        End If

    End Sub

    Private Sub ListCatgoria_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListCatgoria.SelectedIndexChanged

    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles btnActualizar.Click
        Txt_IdProducto.Enabled = True
        TxtNombreProducto.Enabled = True
        box_categoria.Enabled = True
        FechaIngreso.Enabled = True
        TxtPVenta.Enabled = True
        TxtPCompra.Enabled = True


        If ListIdProducto.SelectedIndex >= 0 Then
            ' Actualizar los valores en los ListBox
            ListIdProducto.Items(ListIdProducto.SelectedIndex) = Txt_IdProducto.Text
            ListNombreProducto.Items(ListIdProducto.SelectedIndex) = TxtNombreProducto.Text
            ListCatgoria.Items(ListIdProducto.SelectedIndex) = box_categoria.Text
            ListFechaIngreso.Items(ListFechaIngreso.SelectedIndex) = FechaIngreso.Text
            ListPVenta.Items(ListPVenta.SelectedIndex) = TxtPVenta.Text
            ListPCompra.Items(ListPCompra.SelectedIndex) = TxtPCompra.Text

            ' Bloquear edición después de guardar
            Txt_IdProducto.Text = ""
            TxtNombreProducto.Text = ""
            box_categoria.Text = ""
            FechaIngreso.SetDate(DateTime.Now)
            TxtPVenta.Text = ""
            TxtPCompra.Text = ""


            btnActualizar.Enabled = True
            btnAgregar.Enabled = True
            btnEliminar.Enabled = False

            MessageBox.Show("Datos actualizados correctamente.", "Confirmación", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Else
            MessageBox.Show("Seleccione un registro antes de editar.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        End If


    End Sub

    Private Sub ListIdProducto_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListIdProducto.SelectedIndexChanged
        If ListIdProducto.SelectedIndex >= 0 Then


            ListNombreProducto.SelectedIndex = ListIdProducto.SelectedIndex
            ListCatgoria.SelectedIndex = ListIdProducto.SelectedIndex
            ListFechaIngreso.SelectedIndex = ListIdProducto.SelectedIndex
            ListPVenta.SelectedIndex = ListIdProducto.SelectedIndex
            ListPCompra.SelectedIndex = ListIdProducto.SelectedIndex

            Txt_IdProducto.Text = ListIdProducto.SelectedItem.ToString()
            TxtNombreProducto.Text = ListNombreProducto.SelectedItem.ToString()
            box_categoria.Text = ListCatgoria.SelectedItem.ToString()
            FechaIngreso.Text = ListFechaIngreso.SelectedItem.ToString()
            TxtPVenta.Text = ListPVenta.SelectedItem.ToString()
            TxtPCompra.Text = ListPCompra.SelectedItem.ToString()


            btnActualizar.Enabled = True
            btnAgregar.Enabled = False
            btnEliminar.Enabled = True
        End If
    End Sub

    Private Sub FechaIngreso_DateChanged(sender As Object, e As DateRangeEventArgs) Handles FechaIngreso.DateChanged

    End Sub

    Private Sub btnEliminar_Click(sender As Object, e As EventArgs) Handles btnEliminar.Click
        ' Verificar si hay un elemento seleccionado en ListCed
        If MsgBox("Está seguro que desea eliminar", vbQuestion + vbYesNo, "Confirmar") = vbYes Then
            If ListIdProducto.SelectedIndex = -1 Then

            Else
                ' Obtener el índice del elemento seleccionado
                Dim index As Integer = ListCed.SelectedIndex

                ' Eliminar el elemento en cada ListBox usando el mismo índice
                ListIdProducto.Items.RemoveAt(index)
                ListNombreProducto.Items.RemoveAt(index)
                ListCatgoria.Items.RemoveAt(index)
                ListFechaIngreso.Items.RemoveAt(index)
                ListPVenta.Items.RemoveAt(index)
                ListPCompra.Items.RemoveAt(index)

            End If
        End If
    End Sub

    Private Sub Label5_Click(sender As Object, e As EventArgs) Handles Label5.Click

    End Sub
End Class