﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FormPrincipal
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FormPrincipal))
        Label1 = New Label()
        Label2 = New Label()
        Label3 = New Label()
        Label4 = New Label()
        Label5 = New Label()
        Label6 = New Label()
        TxtCedula = New TextBox()
        TxtNombre = New TextBox()
        TxtPApellido = New TextBox()
        TxtSApellido = New TextBox()
        TxtCorreo = New TextBox()
        TxtTelefono = New TextBox()
        Label7 = New Label()
        Label8 = New Label()
        Label9 = New Label()
        Label10 = New Label()
        Label11 = New Label()
        Label12 = New Label()
        ListCed = New ListBox()
        ListNombre = New ListBox()
        ListPApellido = New ListBox()
        ListSApellido = New ListBox()
        ListCorreo = New ListBox()
        ListTelefono = New ListBox()
        btnAgregar = New Button()
        Button5 = New Button()
        Button6 = New Button()
        Button7 = New Button()
        mostrarDatosBTN = New Button()
        SuspendLayout()
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.FlatStyle = FlatStyle.Flat
        Label1.Font = New Font("Linux Libertine Display G", 24F, FontStyle.Bold)
        Label1.Location = New Point(38, 53)
        Label1.Name = "Label1"
        Label1.Size = New Size(113, 37)
        Label1.TabIndex = 0
        Label1.Text = "Cedula"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.FlatStyle = FlatStyle.Flat
        Label2.Font = New Font("Linux Libertine Display G", 24F, FontStyle.Bold)
        Label2.Location = New Point(239, 53)
        Label2.Name = "Label2"
        Label2.Size = New Size(125, 37)
        Label2.TabIndex = 0
        Label2.Text = "Nombre"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.FlatStyle = FlatStyle.Flat
        Label3.Font = New Font("Linux Libertine Display G", 24F, FontStyle.Bold)
        Label3.Location = New Point(443, 53)
        Label3.Name = "Label3"
        Label3.Size = New Size(235, 37)
        Label3.TabIndex = 0
        Label3.Text = "Primer Apellido"
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.FlatStyle = FlatStyle.Flat
        Label4.Font = New Font("Linux Libertine Display G", 24F, FontStyle.Bold)
        Label4.Location = New Point(1081, 53)
        Label4.Name = "Label4"
        Label4.Size = New Size(110, 37)
        Label4.TabIndex = 0
        Label4.Text = "Correo"
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.FlatStyle = FlatStyle.Flat
        Label5.Font = New Font("Linux Libertine Display G", 24F, FontStyle.Bold)
        Label5.Location = New Point(748, 53)
        Label5.Name = "Label5"
        Label5.Size = New Size(258, 37)
        Label5.TabIndex = 0
        Label5.Text = "Segundo Apellido"
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.FlatStyle = FlatStyle.Flat
        Label6.Font = New Font("Linux Libertine Display G", 24F, FontStyle.Bold)
        Label6.Location = New Point(1252, 53)
        Label6.Name = "Label6"
        Label6.Size = New Size(135, 37)
        Label6.TabIndex = 0
        Label6.Text = "Télefono"
        ' 
        ' TxtCedula
        ' 
        TxtCedula.BorderStyle = BorderStyle.FixedSingle
        TxtCedula.Font = New Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        TxtCedula.ForeColor = SystemColors.InfoText
        TxtCedula.Location = New Point(38, 93)
        TxtCedula.Name = "TxtCedula"
        TxtCedula.Size = New Size(122, 33)
        TxtCedula.TabIndex = 1
        ' 
        ' TxtNombre
        ' 
        TxtNombre.BorderStyle = BorderStyle.FixedSingle
        TxtNombre.Font = New Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        TxtNombre.ForeColor = SystemColors.InfoText
        TxtNombre.Location = New Point(239, 93)
        TxtNombre.Name = "TxtNombre"
        TxtNombre.Size = New Size(144, 33)
        TxtNombre.TabIndex = 1
        ' 
        ' TxtPApellido
        ' 
        TxtPApellido.BorderStyle = BorderStyle.FixedSingle
        TxtPApellido.Font = New Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        TxtPApellido.ForeColor = SystemColors.InfoText
        TxtPApellido.Location = New Point(443, 93)
        TxtPApellido.Name = "TxtPApellido"
        TxtPApellido.Size = New Size(257, 33)
        TxtPApellido.TabIndex = 1
        ' 
        ' TxtSApellido
        ' 
        TxtSApellido.BorderStyle = BorderStyle.FixedSingle
        TxtSApellido.Font = New Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        TxtSApellido.ForeColor = SystemColors.InfoText
        TxtSApellido.Location = New Point(748, 93)
        TxtSApellido.Name = "TxtSApellido"
        TxtSApellido.Size = New Size(277, 33)
        TxtSApellido.TabIndex = 1
        ' 
        ' TxtCorreo
        ' 
        TxtCorreo.BorderStyle = BorderStyle.FixedSingle
        TxtCorreo.Font = New Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        TxtCorreo.ForeColor = SystemColors.InfoText
        TxtCorreo.Location = New Point(1081, 93)
        TxtCorreo.Name = "TxtCorreo"
        TxtCorreo.Size = New Size(123, 33)
        TxtCorreo.TabIndex = 1
        ' 
        ' TxtTelefono
        ' 
        TxtTelefono.BorderStyle = BorderStyle.FixedSingle
        TxtTelefono.Font = New Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        TxtTelefono.ForeColor = SystemColors.InfoText
        TxtTelefono.Location = New Point(1252, 93)
        TxtTelefono.Name = "TxtTelefono"
        TxtTelefono.Size = New Size(150, 33)
        TxtTelefono.TabIndex = 1
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.FlatStyle = FlatStyle.Flat
        Label7.Font = New Font("Linux Libertine Display G", 24F, FontStyle.Bold)
        Label7.Location = New Point(44, 400)
        Label7.Name = "Label7"
        Label7.Size = New Size(113, 37)
        Label7.TabIndex = 0
        Label7.Text = "Cedula"
        ' 
        ' Label8
        ' 
        Label8.AutoSize = True
        Label8.FlatStyle = FlatStyle.Flat
        Label8.Font = New Font("Linux Libertine Display G", 24F, FontStyle.Bold)
        Label8.Location = New Point(449, 406)
        Label8.Name = "Label8"
        Label8.Size = New Size(235, 37)
        Label8.TabIndex = 0
        Label8.Text = "Primer Apellido"
        ' 
        ' Label9
        ' 
        Label9.AutoSize = True
        Label9.FlatStyle = FlatStyle.Flat
        Label9.Font = New Font("Linux Libertine Display G", 24F, FontStyle.Bold)
        Label9.Location = New Point(1258, 406)
        Label9.Name = "Label9"
        Label9.Size = New Size(135, 37)
        Label9.TabIndex = 0
        Label9.Text = "Télefono"
        ' 
        ' Label10
        ' 
        Label10.AutoSize = True
        Label10.FlatStyle = FlatStyle.Flat
        Label10.Font = New Font("Linux Libertine Display G", 24F, FontStyle.Bold)
        Label10.Location = New Point(1087, 406)
        Label10.Name = "Label10"
        Label10.Size = New Size(110, 37)
        Label10.TabIndex = 0
        Label10.Text = "Correo"
        ' 
        ' Label11
        ' 
        Label11.AutoSize = True
        Label11.FlatStyle = FlatStyle.Flat
        Label11.Font = New Font("Linux Libertine Display G", 24F, FontStyle.Bold)
        Label11.Location = New Point(245, 400)
        Label11.Name = "Label11"
        Label11.Size = New Size(125, 37)
        Label11.TabIndex = 0
        Label11.Text = "Nombre"
        ' 
        ' Label12
        ' 
        Label12.AutoSize = True
        Label12.FlatStyle = FlatStyle.Flat
        Label12.Font = New Font("Linux Libertine Display G", 24F, FontStyle.Bold)
        Label12.Location = New Point(754, 406)
        Label12.Name = "Label12"
        Label12.Size = New Size(258, 37)
        Label12.TabIndex = 0
        Label12.Text = "Segundo Apellido"
        ' 
        ' ListCed
        ' 
        ListCed.FormattingEnabled = True
        ListCed.ItemHeight = 15
        ListCed.Location = New Point(44, 453)
        ListCed.Name = "ListCed"
        ListCed.Size = New Size(130, 154)
        ListCed.TabIndex = 2
        ' 
        ' ListNombre
        ' 
        ListNombre.FormattingEnabled = True
        ListNombre.ItemHeight = 15
        ListNombre.Location = New Point(245, 453)
        ListNombre.Name = "ListNombre"
        ListNombre.Size = New Size(144, 154)
        ListNombre.TabIndex = 2
        ' 
        ' ListPApellido
        ' 
        ListPApellido.FormattingEnabled = True
        ListPApellido.ItemHeight = 15
        ListPApellido.Location = New Point(455, 453)
        ListPApellido.Name = "ListPApellido"
        ListPApellido.Size = New Size(251, 154)
        ListPApellido.TabIndex = 2
        ' 
        ' ListSApellido
        ' 
        ListSApellido.FormattingEnabled = True
        ListSApellido.ItemHeight = 15
        ListSApellido.Location = New Point(754, 453)
        ListSApellido.Name = "ListSApellido"
        ListSApellido.Size = New Size(277, 154)
        ListSApellido.TabIndex = 2
        ' 
        ' ListCorreo
        ' 
        ListCorreo.FormattingEnabled = True
        ListCorreo.ItemHeight = 15
        ListCorreo.Location = New Point(1096, 453)
        ListCorreo.Name = "ListCorreo"
        ListCorreo.Size = New Size(125, 154)
        ListCorreo.TabIndex = 2
        ' 
        ' ListTelefono
        ' 
        ListTelefono.FormattingEnabled = True
        ListTelefono.ItemHeight = 15
        ListTelefono.Location = New Point(1264, 453)
        ListTelefono.Name = "ListTelefono"
        ListTelefono.Size = New Size(144, 154)
        ListTelefono.TabIndex = 2
        ' 
        ' btnAgregar
        ' 
        btnAgregar.Font = New Font("Segoe UI", 15.75F, FontStyle.Bold)
        btnAgregar.Location = New Point(233, 238)
        btnAgregar.Name = "btnAgregar"
        btnAgregar.Size = New Size(150, 41)
        btnAgregar.TabIndex = 6
        btnAgregar.Text = "Agregar"
        btnAgregar.UseVisualStyleBackColor = True
        ' 
        ' Button5
        ' 
        Button5.Font = New Font("Segoe UI", 15.75F, FontStyle.Bold)
        Button5.Location = New Point(676, 238)
        Button5.Name = "Button5"
        Button5.Size = New Size(150, 35)
        Button5.TabIndex = 6
        Button5.Text = "Actualizar"
        Button5.UseVisualStyleBackColor = True
        ' 
        ' Button6
        ' 
        Button6.Font = New Font("Segoe UI", 15.75F, FontStyle.Bold)
        Button6.Location = New Point(1164, 238)
        Button6.Name = "Button6"
        Button6.Size = New Size(150, 41)
        Button6.TabIndex = 6
        Button6.Text = "Eliminar"
        Button6.UseVisualStyleBackColor = True
        ' 
        ' Button7
        ' 
        Button7.Font = New Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Button7.Location = New Point(1425, 1)
        Button7.Name = "Button7"
        Button7.Size = New Size(43, 37)
        Button7.TabIndex = 7
        Button7.Text = "+"
        Button7.UseVisualStyleBackColor = True
        ' 
        ' mostrarDatosBTN
        ' 
        mostrarDatosBTN.Font = New Font("Segoe UI", 15.75F, FontStyle.Bold)
        mostrarDatosBTN.Location = New Point(878, 232)
        mostrarDatosBTN.Name = "mostrarDatosBTN"
        mostrarDatosBTN.Size = New Size(233, 41)
        mostrarDatosBTN.TabIndex = 8
        mostrarDatosBTN.Text = "Mostrar Datos"
        mostrarDatosBTN.UseVisualStyleBackColor = True
        ' 
        ' FormPrincipal
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), Image)
        BackgroundImageLayout = ImageLayout.Stretch
        ClientSize = New Size(1469, 684)
        ControlBox = False
        Controls.Add(mostrarDatosBTN)
        Controls.Add(Button7)
        Controls.Add(Button6)
        Controls.Add(Button5)
        Controls.Add(btnAgregar)
        Controls.Add(ListSApellido)
        Controls.Add(ListPApellido)
        Controls.Add(ListTelefono)
        Controls.Add(ListCorreo)
        Controls.Add(ListNombre)
        Controls.Add(ListCed)
        Controls.Add(TxtTelefono)
        Controls.Add(TxtCorreo)
        Controls.Add(TxtSApellido)
        Controls.Add(TxtPApellido)
        Controls.Add(TxtNombre)
        Controls.Add(TxtCedula)
        Controls.Add(Label12)
        Controls.Add(Label5)
        Controls.Add(Label11)
        Controls.Add(Label2)
        Controls.Add(Label10)
        Controls.Add(Label4)
        Controls.Add(Label9)
        Controls.Add(Label8)
        Controls.Add(Label6)
        Controls.Add(Label7)
        Controls.Add(Label3)
        Controls.Add(Label1)
        Cursor = Cursors.Cross
        FormBorderStyle = FormBorderStyle.Fixed3D
        Name = "FormPrincipal"
        Text = "Menú Principal"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents TxtCedula As TextBox
    Friend WithEvents TxtNombre As TextBox
    Friend WithEvents TxtPApellido As TextBox
    Friend WithEvents TxtSApellido As TextBox
    Friend WithEvents TxtCorreo As TextBox
    Friend WithEvents TxtTelefono As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents ListCed As ListBox
    Friend WithEvents ListNombre As ListBox
    Friend WithEvents ListPApellido As ListBox
    Friend WithEvents ListSApellido As ListBox
    Friend WithEvents ListCorreo As ListBox
    Friend WithEvents ListTelefono As ListBox
    Friend WithEvents btnAgregar As Button
    Friend WithEvents Button5 As Button
    Friend WithEvents Button6 As Button
    Friend WithEvents Button7 As Button
    Friend WithEvents mostrarDatosBTN As Button

End Class
